const express = require('express');
const router = express.Router();
const notificationController = require('../controllers/notificationController');
const auth = require('../middleware/auth');

router.get('/', (req, res, next) => {
  if (req.query.phone) return next();
  return auth(req, res, next);
}, notificationController.getNotifications);

router.put('/read-all', (req, res, next) => {
  if (req.query.phone) return next();
  return auth(req, res, next);
}, notificationController.markAllAsRead);

router.put('/:id/read', auth, notificationController.markAsRead);

// Protect the broadcast so only admins can do it
router.post('/broadcast', auth, notificationController.broadcast);

module.exports = router;
