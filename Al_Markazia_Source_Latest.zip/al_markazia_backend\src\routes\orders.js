const express = require('express');
const rateLimit = require('express-rate-limit');
const authenticateToken = require('../middleware/auth');
const { createOrder, getOrders, updateOrderStatus, getCustomerOrders, updateOrderTimer, submitOrderRating, cancelOrder, handleCancellationRequest } = require('../controllers/orderController');

const logger = require('../utils/logger');

const router = express.Router();

const orderLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 minutes
  max: 10, // Limit each IP to 10 requests per windowMs
  message: { error: 'تم تجاوز الحد المسموح به للطلبات. الرجاء المحاولة بعد قليل.' },
  handler: (req, res, next, options) => {
    logger.security('Rate limit triggered', { 
      ip: req.ip, 
      endpoint: req.originalUrl,
      timestamp: new Date().toISOString()
    });
    res.status(options.statusCode).send(options.message);
  }
});

// Allow guests (app) to create orders with rate limiting
router.post('/', orderLimiter, createOrder);

// Only admin can view and update
router.get('/', authenticateToken, getOrders);
router.patch('/:id/status', authenticateToken, updateOrderStatus);
router.patch('/:id/timer', authenticateToken, updateOrderTimer);
router.patch('/:id/rate', submitOrderRating);
router.post('/:id/cancel', (req, res, next) => {
  // If explicitly requested as Admin, authenticate. 
  // Otherwise proceed (controller will check phone for customers)
  if (req.body.isAdmin) return authenticateToken(req, res, next);
  next();
}, cancelOrder);

router.post('/:id/handle-cancellation', authenticateToken, handleCancellationRequest);

// Allow guests (app) to get their own orders by phone
router.get('/customer/:phone', getCustomerOrders);

module.exports = router;
