const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const socketIo = require('../socket');
const firebaseService = require('../services/firebaseService');
const logger = require('../utils/logger');

exports.getNotifications = async (req, res) => {
  try {
    const { phone } = req.query; 

    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    let whereClause = {
      createdAt: { gte: thirtyDaysAgo }
    };

    if (phone) {
      // Customer getting their notifications + broadcasts
      whereClause = { 
        ...whereClause,
        OR: [
          { customerPhone: phone },
          { type: 'broadcast' }
        ]
       };
    } else {
      // Admin getting admin notifications (customerPhone null and not broadcast)
      whereClause = { 
        ...whereClause,
        customerPhone: null,
        type: { not: 'broadcast' }
      };
    }

    const notifications = await prisma.notification.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      take: 100 // Limit to latest 100
    });

    res.json(notifications);
  } catch (error) {
    logger.error('Fetch notifications error', { error: error.message, stack: error.stack, phone: req.query.phone });
    res.status(500).json({ error: 'Failed to fetch notifications' });
  }
};

exports.markAsRead = async (req, res) => {
  try {
    const { id } = req.params;
    await prisma.notification.update({
      where: { id: parseInt(id) },
      data: { isRead: true }
    });
    res.json({ success: true });
  } catch (error) {
    logger.error('Failed to mark notification as read', { error: error.message, id: req.params.id });
    res.status(500).json({ error: 'Failed to mark as read' });
  }
};

exports.markAllAsRead = async (req, res) => {
  try {
    const { phone } = req.query; // If provided, mark for specific customer, else for admin
    
    let whereClause = {};
    if (phone) {
      whereClause = { customerPhone: phone, isRead: false };
    } else {
      whereClause = { customerPhone: null, type: { not: 'broadcast' }, isRead: false };
    }

    await prisma.notification.updateMany({
      where: whereClause,
      data: { isRead: true }
    });
    
    res.json({ success: true });
  } catch (error) {
    logger.error('Mark all as read error', { error: error.message, phone: req.query.phone });
    res.status(500).json({ error: 'Failed to mark all as read' });
  }
};

exports.broadcast = async (req, res) => {
  try {
    const { title, message } = req.body;

    const notification = await prisma.notification.create({
      data: {
        title,
        message,
        type: 'broadcast',
      }
    });

    // Emit to all connected clients
    const io = socketIo.getIO();
    if (io) io.emit('new_broadcast', notification);

    // Send via FCM to all users (topic)
    await firebaseService.sendBroadcast(title, message, {
      type: 'broadcast',
      id: notification.id.toString(), // Ensure ID is a string for FCM data
      createdAt: notification.createdAt.toISOString()
    });

    logger.info('Broadcast notification sent', { title, notificationId: notification.id });
    res.status(201).json(notification);
  } catch (error) {
    logger.error('Broadcast error', { error: error.message, body: req.body });
    res.status(500).json({ error: 'Failed to broadcast notification' });
  }
};

// --- Automated Cleanup Task ---
// Runs every 24 hours to permanently delete notifications older than 30 days
setInterval(async () => {
  try {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const deletedCount = await prisma.notification.deleteMany({
      where: {
        createdAt: { lt: thirtyDaysAgo }
      }
    });

    if (deletedCount.count > 0) {
      logger.info(`🧹 Cleanup: Deleted ${deletedCount.count} expired notifications.`);
    }
  } catch (error) {
    logger.error('❌ Cleanup Task Error', { error: error.message });
  }
}, 24 * 60 * 60 * 1000); // 24 Hours
