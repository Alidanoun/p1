import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';
import '../models/menu_item.dart';
import '../models/order_model.dart';

class ApiService {
  // --- CONFIGURATION ---
  static String get baseUrl {
    final ip = dotenv.get('SERVER_IP', fallback: 'localhost');
    final port = dotenv.get('SERVER_PORT', fallback: '5000');
    return 'http://$ip:$port';
  }


  Future<List<Category>> fetchCategories() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/categories')).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final List data = json.decode(utf8.decode(response.bodyBytes));
        return data.map((json) {
          if (json['image'] != null && json['image'].toString().startsWith('/')) {
            json['image'] = '$baseUrl${json['image']}';
          }
          return Category.fromJson(json);
        }).toList();
      } else {
        throw Exception('Failed to load categories');
      }
    } catch (e) {
      throw Exception('Connection error. Make sure the server is running.');
    }
  }

  Future<List<MenuItem>> fetchMenuItems() async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/items')).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final List data = json.decode(utf8.decode(response.bodyBytes));
        return data.map((json) {
          if (json['image'] != null && json['image'].toString().startsWith('/')) {
            json['image'] = '$baseUrl${json['image']}';
          }
          return MenuItem.fromJson(json);
        }).toList();
      } else {
        throw Exception('Failed to load menu items');
      }
    } catch (e) {
      throw Exception('Connection error. Make sure the server is running.');
    }
  }

  Future<http.Response> _interceptedRequest(Future<http.Response> Function() request) async {
    final response = await request();
    if (response.statusCode == 401) {
       _handle401();
    }
    return response;
  }

  static Function()? onAuthError;

  void _handle401() {
    print('Token expired or invalid: 401');
    if (onAuthError != null) onAuthError!();
  }

  Future<OrderModel?> placeOrder(OrderModel order) async {
    try {
      final response = await _interceptedRequest(() => http.post(
        Uri.parse('$baseUrl/orders'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(order.toJson()),
      ).timeout(const Duration(seconds: 10)));

      if (response.statusCode == 201) {
        final Map<String, dynamic> data = json.decode(utf8.decode(response.bodyBytes));
        data['cartItems'] = order.cartItems.map((e) => e.toJson()).toList();
        return OrderModel.fromJson(data);
      } else {
        final Map<String, dynamic> errorData = json.decode(utf8.decode(response.bodyBytes));
        if (errorData['error'] == 'PRICE_CHANGED') {
           throw Exception('PRICE_CHANGED:${errorData['message']}');
        }
        throw Exception(errorData['error'] ?? 'Failed to place order');
      }
    } catch (e) {
      print('API Error: $e');
      throw Exception('Failed to send order: $e');
    }
  }

  Future<Map<String, dynamic>> loginCustomer(String phone) async {
    final response = await http.post(
      Uri.parse('$baseUrl/customers/login'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'phone': phone}),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      return json.decode(utf8.decode(response.bodyBytes));
    } else {
      final errorData = json.decode(utf8.decode(response.bodyBytes));
      throw Exception(errorData['error'] ?? 'Login failed');
    }
  }

  Future<Map<String, dynamic>> fetchCustomerProfile(String phone) async {
    final response = await http.post(
      Uri.parse('$baseUrl/customers/login'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'phone': phone}),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(utf8.decode(response.bodyBytes));
      return data['customer'];
    } else {
      throw Exception('Failed to fetch profile');
    }
  }

  Future<Map<String, dynamic>> registerCustomer(String name, String phone) async {
    final response = await http.post(
      Uri.parse('$baseUrl/customers/register'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'name': name, 'phone': phone}),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode == 200) {
      return json.decode(utf8.decode(response.bodyBytes));
    } else {
      final errorData = json.decode(utf8.decode(response.bodyBytes));
      throw Exception(errorData['error'] ?? 'Registration failed');
    }
  }

  Future<List<OrderModel>> fetchCustomerOrders(String phone) async {
    try {
      final response = await _interceptedRequest(() => http.get(Uri.parse('$baseUrl/orders/customer/$phone')).timeout(const Duration(seconds: 10)));
      if (response.statusCode == 200) {
        final List data = json.decode(utf8.decode(response.bodyBytes));
        return data.map((json) => OrderModel.fromJson(json)).toList();
      }
      return [];
    } catch (e) {
      print('Fetch Customer Orders Error: $e');
      return [];
    }
  }

  // --- Reviews API ---
  Future<List<Review>> fetchItemReviews(int itemId) async {
    try {
      final response = await http.get(Uri.parse('$baseUrl/reviews/item/$itemId')).timeout(const Duration(seconds: 5));
      if (response.statusCode == 200) {
        final List data = json.decode(utf8.decode(response.bodyBytes));
        return data.map((json) => Review.fromJson(json)).toList();
      }
      return [];
    } catch (e) {
      print('Fetch Reviews Error: $e');
      return [];
    }
  }

  Future<void> submitReview(int itemId, String customerName, int rating, String comment) async {
    final response = await http.post(
      Uri.parse('$baseUrl/reviews'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'itemId': itemId,
        'customerName': customerName,
        'rating': rating,
        'comment': comment,
      }),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode != 201) {
      final errorData = json.decode(utf8.decode(response.bodyBytes));
      throw Exception(errorData['error'] ?? 'Failed to submit review');
    }
  }

  Future<void> rateOrder(String orderId, int rating, String comment) async {
    final response = await http.patch(
      Uri.parse('$baseUrl/orders/$orderId/rate'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'rating': rating,
        'ratingComment': comment,
      }),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode != 200) {
      final errorData = json.decode(utf8.decode(response.bodyBytes));
      throw Exception(errorData['error'] ?? 'Failed to submit review');
    }
  }

  Future<void> cancelOrder({
    required String orderId,
    required String reason,
    String? customerPhone,
    String? managerPassword,
    bool isAdmin = false,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/orders/$orderId/cancel'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'reason': reason,
        'customerPhone': customerPhone,
        'managerPassword': managerPassword,
        'isAdmin': isAdmin,
      }),
    ).timeout(const Duration(seconds: 10));

    if (response.statusCode != 200) {
      final errorData = json.decode(utf8.decode(response.bodyBytes));
      throw Exception(errorData['error'] ?? 'Failed to cancel order');
    }
  }
}
