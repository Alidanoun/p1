const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const socketIo = require('../socket');
const xss = require('xss');
const firebaseService = require('../services/firebaseService');
const logger = require('../utils/logger');

exports.getCustomerOrders = async (req, res) => {
  try {
    const { phone } = req.params;
    const orders = await prisma.order.findMany({
      where: { customerPhone: phone },
      include: { 
        orderItems: true,
        cancellation: true 
      },
      orderBy: { createdAt: 'desc' }
    });

    res.json(orders.map(mapOrderResponse));
  } catch (error) {
    logger.error('Fetch customer orders error', { error: error.message, stack: error.stack, phone: req.params.phone });
    res.status(500).json({ error: 'Failed to fetch customer orders' });
  }
};

// Utility for professional order number: ORD-YYYYMMDD-XXXX
const generateOrderNumber = async () => {
  const date = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const count = await prisma.order.count();
  const serial = (count + 1).toString().padStart(4, '0');
  return `ORD-${date}-${serial}`;
};

exports.createOrder = async (req, res) => {
  try {
    const { 
      customerName, 
      customerPhone, 
      orderType, 
      paymentMethod, 
      address, 
      notes, 
      cartItems, 
      deliveryFee: requestedDeliveryFee, 
      tax: requestedTax 
    } = req.body;

    // Check if customer is blacklisted
    const customer = await prisma.customer.findUnique({ where: { phone: customerPhone } });
    if (customer && customer.isBlacklisted) {
      return res.status(403).json({ error: 'نعتذر منك، تم حظر رقمك من الطلب مؤقتاً بسبب تكرار الإلغاءات المرفوضة.' });
    }

    // LOGIC-01: Validations
    if (!customerPhone || !cartItems || !Array.isArray(cartItems) || cartItems.length === 0) {
      logger.warn('Order rejected: Empty cart or invalid data', { phone: customerPhone });
      return res.status(400).json({ error: 'السلة فارغة أو هناك خطأ في البيانات' });
    }

    let clientSubtotal = 0;
    let actualSubtotal = 0;
    const validatedCartItems = [];

    for (const item of cartItems) {
      const qty = parseInt(item.quantity || item.qty || 1);
      const itemId = parseInt(item.productId || item.id || 0);

      // LOGIC-01: Validate quantity bounds
      if (qty < 1 || qty > 50) {
        logger.warn('Order rejected: Invalid quantity bounds', { phone: customerPhone, itemId, qty });
        return res.status(400).json({ error: 'كمية الصنف تتجاوز الحد المسموح أو غير صالحة' });
      }

      if (itemId <= 0) {
        return res.status(400).json({ error: 'معرف الصنف غير صالح' });
      }

      // Re-fetch item price (BUG-02)
      const dbItem = await prisma.item.findUnique({ where: { id: itemId } });
      if (!dbItem) {
        return res.status(404).json({ error: `الصنف غير موجود أو تم حذفه` });
      }

      let itemActualPrice = dbItem.basePrice;

      // Re-fetch option prices if optionIds provided
      const optionIds = item.optionIds || [];
      if (Array.isArray(optionIds) && optionIds.length > 0) {
        // Strict Validation: Fetch options and verify their parent groups belong to this itemId
        const dbOptions = await prisma.itemOption.findMany({
          where: { id: { in: optionIds } },
          include: { group: true }
        });

        for (const opt of dbOptions) {
          // Verify integrity: Option -> Group -> Item link
          if (opt.group.itemId !== itemId) {
            logger.warn('Integrity violation: Option does not belong to item', {
              phone: customerPhone,
              itemId,
              optionId: opt.id,
              actualOwnerId: opt.group.itemId
            });
            return res.status(400).json({
              error: 'خطأ في نزاهة البيانات. تم اختيار إضافات لا تنتمي لهذا الصنف.'
            });
          }
          itemActualPrice += opt.price;
        }
      }

      const clientPrice = parseFloat(item.unitPrice || item.basePrice || item.price || 0);
      clientSubtotal += (clientPrice * qty);
      actualSubtotal += (itemActualPrice * qty);

      validatedCartItems.push({
        itemId: dbItem.id,
        itemName: dbItem.title,
        itemNameEn: dbItem.titleEn || dbItem.title,
        quantity: qty,
        unitPrice: itemActualPrice,
        lineTotal: itemActualPrice * qty,
        selectedOptions: item.optionsText || null,
        selectedOptionsEn: item.optionsTextEn || null
      });
    }

    // LOGIC-04 Stale cart detection (diff check)
    if (clientSubtotal > 0) {
      const diffPercent = Math.abs(actualSubtotal - clientSubtotal) / clientSubtotal;
      if (diffPercent > 0.01) {
        logger.warn('PRICE_CHANGED detected', { phone: customerPhone, expected: clientSubtotal, actual: actualSubtotal, diffPercent });
        return res.status(400).json({
          error: 'PRICE_CHANGED', // specific keyword for Flutter to catch
          message: 'تم تحديث أسعار بعض الأصناف. يرجى مراجعة سلتك قبل التأكيد.'
        });
      }
    }

    const orderNumber = await generateOrderNumber();

    const subtotal = actualSubtotal;
    const tax = (requestedTax != null && !isNaN(parseFloat(requestedTax))) ? parseFloat(requestedTax) : 0;
    const deliveryFee = (requestedDeliveryFee != null && !isNaN(parseFloat(requestedDeliveryFee))) ? parseFloat(requestedDeliveryFee) : (orderType === 'delivery' ? 1.00 : 0);
    const total = subtotal + tax + deliveryFee;

    const { newOrder, adminNotification } = await prisma.$transaction(async (tx) => {
      const order = await tx.order.create({
        data: {
          orderNumber,
          customerName: customerName || 'زبون',
          customerPhone,
          orderType: orderType || 'takeaway',
          paymentMethod: paymentMethod || 'cash',
          subtotal,
          tax,
          deliveryFee,
          total,
          status: 'pending',
          address: address ? xss(address) : address,
          notes: notes ? xss(notes) : notes,
          orderItems: {
            create: validatedCartItems
          }
        },
        include: { orderItems: true }
      });

      const notification = await tx.notification.create({
        data: {
          title: 'طلب جديد 🔔',
          titleEn: 'New Order 🔔',
          message: `طلب جديد (${order.orderNumber}) من ${order.customerName} بقيمة ${order.total} د.أ`,
          messageEn: `New order (${order.orderNumber}) from ${order.customerName} - ${order.total} JD`,
          type: 'order_created',
          customerPhone: null, // Admin
          orderId: order.id,
          targetRoute: '/orders'
        }
      });

      return { newOrder: order, adminNotification: notification };
    });

    // --- Emit Admin Notification ---
    try {
      const io = socketIo.getIO();
      if (io) io.to('admins').emit('new_admin_notification', adminNotification);
    } catch (socketErr) {
      logger.error('Failed to send real-time notification', { error: socketErr.message });
    }

    // --- AUTO-ACCEPT LOGIC (15 Seconds) ---
    // If the order is still 'pending' after 15s, auto-confirm it.
    setTimeout(async () => {
      try {
        const currentOrder = await prisma.order.findUnique({ where: { id: newOrder.id } });
        if (currentOrder && currentOrder.status === 'pending') {
          logger.info('Auto-accepting order after 15s timeout', { orderId: newOrder.id, orderNumber: newOrder.orderNumber });
          await exports.performStatusUpdate(newOrder.id, 'preparing');
        }
      } catch (timerErr) {
        logger.error('Auto-accept timer error', { error: timerErr.message, orderId: newOrder.id });
      }
    }, 15000);

    res.status(201).json(newOrder);
  } catch (error) {
    logger.error('Order Creation Error', { error: error.message, stack: error.stack, body: req.body });
    res.status(500).json({
      error: 'عذراً، فشل في نظام إنشاء الطلبات الرقمي. يرجى مراجعة الإدارة.',
      details: error.message
    });
  }
};

// Helper for professional order mapping (Front/Mobile sync)
const mapOrderResponse = (order) => ({
  ...order,
  id: order.id.toString(),
  totalPrice: order.total,
  amount: order.total, // Added as alias for some frontend components
  deliveryFee: order.deliveryFee || 0,
  tax: order.tax || 0,
  subtotal: order.subtotal || 0,
  cartItems: (order.orderItems || []).map(item => ({
    ...item,
    id: item.id.toString(),
    qty: item.quantity,
    quantity: item.quantity,
    title: item.itemName,
    titleEn: item.itemNameEn,
    optionsText: item.selectedOptions,
    optionsTextEn: item.selectedOptionsEn,
    price: item.unitPrice,
    unitPrice: item.unitPrice
  }))
});

exports.getOrders = async (req, res) => {
  try {
    const { active_only, time_range } = req.query;

    let whereClause = {};

    if (active_only === 'true') {
      const now = new Date();
      const hour = now.getHours();

      // Business Shift: 8:00 to 23:00 (11 PM)
      if (hour >= 8 && hour < 23) {
        const shiftStart = new Date(now);
        shiftStart.setHours(8, 0, 0, 0);

        whereClause.OR = [
          { status: { not: 'delivered' } },
          { 
            status: 'delivered', 
            updatedAt: { gte: shiftStart } 
          }
        ];
      } else {
        // After 11 PM until 8 AM next day, don't show delivered ones (Archived)
        whereClause.status = { not: 'delivered' };
      }
    }

    if (time_range) {
      const now = new Date();
      if (time_range === 'day') {
        const startOfDay = new Date(now.setHours(0, 0, 0, 0));
        whereClause.createdAt = { gte: startOfDay };
      } else if (time_range === 'week') {
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        whereClause.createdAt = { gte: weekAgo };
      } else if (time_range === 'month') {
        const monthAgo = new Date();
        monthAgo.setMonth(monthAgo.getMonth() - 1);
        whereClause.createdAt = { gte: monthAgo };
      }
    }

    const orders = await prisma.order.findMany({
      where: whereClause,
      include: {
        orderItems: true,
        customer: true,
        payment: true,
        cancellation: true
      },
      orderBy: { createdAt: 'desc' },
      take: 200 // Safety limit
    });

    res.json(orders.map(mapOrderResponse));
  } catch (error) {
    logger.error('Fetch orders error', { error: error.message, stack: error.stack });
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
};

// Internal helper to perform status updates with all side effects (Notifications, Socket, FCM)
exports.performStatusUpdate = async (id, status, paymentStatus = null, rejectionReason = null) => {
  const existingOrder = await prisma.order.findUnique({
    where: { id: parseInt(id) },
    include: { customer: true }
  });

  if (!existingOrder) throw new Error('Order not found');

  const { updatedOrder, customerNotification } = await prisma.$transaction(async (tx) => {
    const data = { updatedAt: new Date() };
    if (status) data.status = status;
    if (paymentStatus) data.paymentStatus = paymentStatus;

    // Automatically set 20-minute timer if status is 'preparing'
    if (status === 'preparing' && !existingOrder.estimatedReadyAt) {
      const estimatedReadyAt = new Date();
      estimatedReadyAt.setMinutes(estimatedReadyAt.getMinutes() + 20);
      data.estimatedReadyAt = estimatedReadyAt;
    }

    const uOrder = await tx.order.update({
      where: { id: parseInt(id) },
      data,
      include: {
        customer: true,
        orderItems: true
      }
    });

    let statusMsg = 'تم تحديث حالة طلبك.';
    let statusMsgEn = 'Your order status has been updated.';
    
    if (rejectionReason) {
      statusMsg = `تم رفض طلب الإلغاء: ${rejectionReason}`;
      statusMsgEn = `Cancellation request rejected: ${rejectionReason}`;
    }
    else if (status === 'confirmed') { statusMsg = 'تم قبول طلبك! سيتم البدء بالتحضير فوراً 👨‍🍳'; statusMsgEn = 'Your order has been confirmed! Preparation starts now 👨‍🍳'; }
    else if (status === 'preparing') { statusMsg = 'طلبك قيد التحضير 👨‍🍳'; statusMsgEn = 'Your order is being prepared 👨‍🍳'; }
    else if (status === 'ready') {
      statusMsg = uOrder.orderType === 'delivery' 
        ? 'طلبك جاهز وخارج للتوصيل! 🚚' 
        : 'طلبك جاهز وبانتظارك في المطعم! 🛍️';
      statusMsgEn = uOrder.orderType === 'delivery'
        ? 'Your order is ready and out for delivery! 🚚'
        : 'Your order is ready for pickup! 🛍️';
    }
    else if (status === 'delivered') { statusMsg = 'تم تسليم طلبك. بالهناء والشفاء! ❤️'; statusMsgEn = 'Your order has been delivered. Enjoy your meal! ❤️'; }
    else if (status === 'cancelled') { statusMsg = 'تم إلغاء طلبك.'; statusMsgEn = 'Your order has been cancelled.'; }
    else if (status === 'waiting_cancellation') { 
      statusMsg = 'طلب الإلغاء قيد المراجعة وسيتم التواصل معك.'; 
      statusMsgEn = 'Cancellation request is under review; we will contact you.'; 
    }
    else if (status === 'in_route') { 
      statusMsg = 'طلبك في الطريق إليك! 🎁'; 
      statusMsgEn = 'Your order is on the way! 🎁'; 
    }

    const cNotification = await tx.notification.create({
      data: {
        title: 'تحديث حالة الطلب',
        titleEn: 'Order Status Update',
        message: statusMsg,
        messageEn: statusMsgEn,
        type: 'order_status',
        customerPhone: uOrder.customerPhone,
        orderId: uOrder.id,
        targetRoute: '/orders'
      }
    });

    return { updatedOrder: uOrder, customerNotification: cNotification };
  });

  // Side Effects (Async)
  try {
    const io = socketIo.getIO();
    if (io) {
      // Notify Admin Panel (to move card)
      io.to('admins').emit('order_status_updated', updatedOrder);

      // Notify Customer App
      if (updatedOrder.customerPhone) {
        io.to(`customer_${updatedOrder.customerPhone}`).emit('customer_notification', customerNotification);
      }
    }

    if (updatedOrder.customer && updatedOrder.customer.fcmToken) {
      let statusMsg = 'تم تحديث حالة طلبك.';
      if (status === 'confirmed') statusMsg = 'تم قبول طلبك! سيتم البدء بالتحضير فوراً 👨‍🍳';
      else if (status === 'preparing') statusMsg = 'طلبك قيد التحضير 👨‍🍳';
      else if (status === 'ready') {
        statusMsg = updatedOrder.orderType === 'delivery' 
          ? 'طلبك جاهز وخارج للتوصيل! 🚚' 
          : 'طلبك جاهز وبانتظارك في المطعم! 🛍️';
      }
      else if (status === 'delivered') statusMsg = 'تم تسليم طلبك. بالهناء والشفاء! ❤️';
      else if (status === 'cancelled') statusMsg = 'تم إلغاء طلبك.';

      await firebaseService.sendToToken(
        updatedOrder.customer.fcmToken,
        'تحديث حالة الطلب',
        statusMsg,
        {
          type: 'order_status',
          id: customerNotification.id,
          orderId: updatedOrder.id
        }
      );
    }
  } catch (err) {
    logger.error('Side effects error in performStatusUpdate', { error: err.message, orderId: id });
  }

  return updatedOrder;
};

exports.updateOrderStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status, paymentStatus } = req.body;

    const existingOrder = await prisma.order.findUnique({
      where: { id: parseInt(id) }
    });

    if (!existingOrder) return res.status(404).json({ error: 'الطلب غير موجود' });

    if (status && status !== existingOrder.status) {
      const allowedTransitions = {
        'pending': ['confirmed', 'preparing', 'cancelled', 'waiting_cancellation'],
        'confirmed': ['preparing', 'cancelled', 'waiting_cancellation'],
        'preparing': ['ready', 'cancelled', 'waiting_cancellation'],
        'ready': ['delivered', 'cancelled'],
        'in_route': ['delivered', 'cancelled'],
        'delivered': [],
        'cancelled': [],
        'waiting_cancellation': ['cancelled', 'preparing', 'ready']
      };

      const validNextStates = allowedTransitions[existingOrder.status] || [];
      if (!validNextStates.includes(status)) {
        return res.status(400).json({ error: `انتقال غير صالح: من ${existingOrder.status} إلى ${status}` });
      }
    }

    const updatedOrder = await exports.performStatusUpdate(id, status, paymentStatus);
    res.json(mapOrderResponse(updatedOrder));
  } catch (error) {
    logger.error('Update status error', { error: error.message, id: req.params.id });
    res.status(500).json({ error: 'فشل في تحديث حالة الطلب' });
  }
};

exports.cancelOrder = async (req, res) => {
  try {
    const { id } = req.params;
    const { reason, managerPassword, isAdmin } = req.body;
    const orderId = parseInt(id);

    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { customer: true }
    });

    if (!order) return res.status(404).json({ error: 'الطلب غير موجود' });

    // Scenario A: Admin/Manager Cancellation
    if (isAdmin) {
      const storedPwd = await prisma.systemSettings.findUnique({ where: { key: 'manager_password' } });
      const masterPwd = storedPwd ? storedPwd.value : process.env.GENERAL_MANAGER_PASSWORD;

      if (!managerPassword || managerPassword !== masterPwd) {
        return res.status(403).json({ error: 'كلمة مرور المدير العام غير صحيحة' });
      }
      if (!reason) return res.status(400).json({ error: 'يجب ذكر سبب الإلغاء' });

      // Admin can cancel from any "active" state
      const updatedOrder = await prisma.$transaction(async (tx) => {
        const uo = await tx.order.update({
          where: { id: orderId },
          data: { status: 'cancelled' }
        });

        await tx.orderCancellation.create({
          data: {
            orderId,
            reason,
            cancelledBy: 'admin',
            previousStatus: order.status,
            adminName: req.user?.email || 'Admin'
          }
        });
        return uo;
      });

      await exports.performStatusUpdate(orderId, 'cancelled');
      return res.json(mapOrderResponse(updatedOrder));
    }

    // Scenario B: Customer Cancellation
    const { customerPhone } = req.body;
    if (!customerPhone || customerPhone !== order.customerPhone) {
      return res.status(403).json({ error: 'غير مصرح لك بإلغاء هذا الطلب' });
    }

    if (order.status !== 'pending' && order.status !== 'preparing' && order.status !== 'confirmed') {
      return res.status(400).json({ error: 'لا يمكن إلغاء الطلب في هذه المرحلة' });
    }

    const isOtherReason = reason === 'أسباب أخرى' || reason === 'Other reasons';
    const newStatus = isOtherReason ? 'waiting_cancellation' : 'cancelled';

    const updatedOrder = await prisma.$transaction(async (tx) => {
      const uo = await tx.order.update({
        where: { id: orderId },
        data: { status: newStatus }
      });

      await tx.orderCancellation.create({
        data: {
          orderId,
          reason,
          cancelledBy: 'customer',
          previousStatus: order.status
        }
      });
      return uo;
    });

    await exports.performStatusUpdate(orderId, newStatus);

    // If customer cancelled successfully, increment their cancellation counter
    if (newStatus === 'cancelled') {
      await prisma.customer.update({
        where: { phone: order.customerPhone },
        data: { cancellationCount: { increment: 1 } }
      });
    }

    res.json(mapOrderResponse(updatedOrder));

  } catch (error) {
    logger.error('Cancel order error', { error: error.message, id: req.params.id });
    res.status(500).json({ error: 'فشل في عملية إلغاء الطلب' });
  }
};

exports.handleCancellationRequest = async (req, res) => {
  try {
    const { id } = req.params;
    const { action, rejectionReason } = req.body; // action: 'approve' or 'reject'
    const orderId = parseInt(id);

    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { cancellation: true, customer: true }
    });

    if (!order || !order.cancellation) {
      return res.status(404).json({ error: 'طلب الإلغاء غير موجود' });
    }

    if (action === 'approve') {
      await prisma.$transaction(async (tx) => {
        await tx.order.update({
          where: { id: orderId },
          data: { status: 'cancelled' }
        });
        
        await tx.orderCancellation.update({
          where: { orderId },
          data: { status: 'approved' }
        });

        // Increment cancellation count
        const updatedCustomer = await tx.customer.update({
          where: { phone: order.customerPhone },
          data: { cancellationCount: { increment: 1 } }
        });

        // Check if blacklisted (threshold 5)
        if (updatedCustomer.cancellationCount >= 5) {
          await tx.customer.update({
            where: { phone: order.customerPhone },
            data: { isBlacklisted: true }
          });
        }

        // Loyalty Points Compensation if reason is Restaurant Delay
        const delayReason = 'تأخر المطعم في تجهيز الطلب';
        const delayReasonEn = 'Restaurant delay in preparation';
        if (order.cancellation.reason === delayReason || order.cancellation.reason === delayReasonEn) {
          const pointsSetting = await tx.systemSettings.findUnique({ where: { key: 'cancellation_compensation_points' } });
          const pointsToAdd = parseInt(pointsSetting?.value || '50');
          
          await tx.customer.update({
            where: { phone: order.customerPhone },
            data: { points: { increment: pointsToAdd } }
          });
        }
      });

      await exports.performStatusUpdate(orderId, 'cancelled');
      return res.json({ success: true, message: 'تم قبول طلب الإلغاء' });
    } 
    else if (action === 'reject') {
      if (!rejectionReason) return res.status(400).json({ error: 'يجب ذكر سبب الرفض' });

      await prisma.orderCancellation.update({
        where: { orderId },
        data: { 
          status: 'rejected',
          rejectionReason: rejectionReason 
        }
      });

      // Restore status to previous status (e.g. preparing)
      const previousStatus = order.cancellation.previousStatus || 'preparing';
      await prisma.order.update({
        where: { id: orderId },
        data: { status: previousStatus }
      });

      await exports.performStatusUpdate(orderId, previousStatus, null, rejectionReason);
      return res.json({ success: true, message: 'تم رفض طلب الإلغاء' });
    }

    res.status(400).json({ error: 'إجراء غير معروف' });
  } catch (error) {
    logger.error('Handle cancellation error', { error: error.message, id: req.params.id });
    res.status(500).json({ error: 'فشل في معالجة طلب الإلغاء' });
  }
};

exports.updateOrderTimer = async (req, res) => {
  try {
    const { id } = req.params;
    const { minutes } = req.body; // Minutes to add/subtract

    const currentOrder = await prisma.order.findUnique({
      where: { id: parseInt(id) },
      include: { orderItems: true }
    });

    if (!currentOrder) {
      return res.status(404).json({ error: 'الطلب غير موجود' });
    }

    let baseTime = currentOrder.estimatedReadyAt || new Date();
    const newReadyAt = new Date(baseTime.getTime() + minutes * 60000);

    const updatedOrder = await prisma.order.update({
      where: { id: parseInt(id) },
      data: {
        estimatedReadyAt: newReadyAt,
        updatedAt: new Date()
      },
      include: {
        orderItems: true,
        customer: true
      }
    });

    // Notify clients via socket
    const io = socketIo.getIO();
    if (io) {
      io.to('admins').emit('order_status_updated', updatedOrder);
      if (updatedOrder.customerPhone) {
        io.to(`customer_${updatedOrder.customerPhone}`).emit('order_updated', mapOrderResponse(updatedOrder));
      }
    }

    res.json(mapOrderResponse(updatedOrder));
  } catch (error) {
    logger.error('Update timer error', { error: error.message, id: req.params.id });
    res.status(500).json({ error: 'فشل في تحديث وقت التحضير' });
  }
};

exports.submitOrderRating = async (req, res) => {
  try {
    const { id } = req.params;
    const { rating, ratingComment } = req.body;

    const updatedOrder = await prisma.order.update({
      where: { id: parseInt(id) },
      data: {
        rating: parseInt(rating),
        ratingComment: ratingComment || null,
        updatedAt: new Date()
      },
      include: {
        orderItems: true,
        customer: true
      }
    });

    // Notify Admin Panel
    const io = socketIo.getIO();
    if (io) {
      io.to('admins').emit('order_status_updated', updatedOrder);
    }

    res.json(mapOrderResponse(updatedOrder));
  } catch (error) {
    logger.error('Submit rating error', { error: error.message, id: req.params.id });
    res.status(500).json({ error: 'فشل في إرسال التقييم' });
  }
};
