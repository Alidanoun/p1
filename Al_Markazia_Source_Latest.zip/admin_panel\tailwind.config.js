/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#0f172a',    // Deep slate
        card: '#1e293b',          // Light slate
        primary: {
          DEFAULT: '#f97316',     // Orange 500
          hover: '#ea580c',       // Orange 600
        },
        text: {
          main: '#f8fafc',
          muted: '#94a3b8',
        },
        danger: '#ef4444',
        success: '#10b981',
      },
      fontFamily: {
        sans: ['Tajawal', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
