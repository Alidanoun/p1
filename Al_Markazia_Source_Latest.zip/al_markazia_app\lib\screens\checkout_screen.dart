import 'package:flutter/material.dart';
import '../models/order_model.dart';
import '../models/cart_item.dart';
import '../services/storage_service.dart';
import '../widgets/custom_snackbar.dart';
import '../services/api_service.dart';
import 'main_nav_screen.dart';
import '../l10n/generated/app_localizations.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({Key? key}) : super(key: key);

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class DeliveryZone {
  final String name;
  final String code;
  final double price;
  DeliveryZone(this.name, this.code, this.price);
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _formKey = GlobalKey<FormState>();
  
  String customerName = '';
  String customerPhone = '';
  String orderType = 'delivery';
  String additionalInfo = ''; // Address or notes
  String street = '';
  String building = '';
  
  // Takeaway specific
  String pickupTiming = 'asap';
  TimeOfDay? selectedTime;

  // Delivery specific
  double deliveryFee = 0.0;
  DeliveryZone? selectedZone;

  final List<DeliveryZone> deliveryZones = [
    // K1: 2.00
    DeliveryZone('البركة', 'K1', 2.00),
    DeliveryZone('أم السماق', 'K1', 2.00),
    DeliveryZone('تلاع العلي', 'K1', 2.00),
    DeliveryZone('شارع الجاردنز', 'K1', 2.00),
    DeliveryZone('شارع المدينة', 'K1', 2.00),
    
    // K2: 2.50
    DeliveryZone('الجندويل', 'K2', 2.50),
    DeliveryZone('المدينة الطبية', 'K2', 2.50),
    DeliveryZone('ضاحية الأمير راشد', 'K2', 2.50),
    DeliveryZone('الرابية', 'K2', 2.50),
    DeliveryZone('ضاحية الروضة', 'K2', 2.50),
    DeliveryZone('ضاحية الرشيد', 'K2', 2.50),
    DeliveryZone('الروابي', 'K2', 2.50),
    DeliveryZone('خلدا', 'K2', 2.50),
    DeliveryZone('مجمع الأعمال', 'K2', 2.50),
    DeliveryZone('مكة مول', 'K2', 2.50),
    DeliveryZone('سيتي مول', 'K2', 2.50),
    DeliveryZone('أم أذينة', 'K2', 2.50),
    DeliveryZone('طلوع نيفين', 'K2', 2.50),

    // K3: 3.00
    DeliveryZone('السادس', 'K3', 3.00),
    DeliveryZone('الخامس', 'K3', 3.00),
    DeliveryZone('الرابع', 'K3', 3.00),
    DeliveryZone('الشميساني', 'K3', 3.00),
    DeliveryZone('صويلح', 'K3', 3.00),
    DeliveryZone('دابوق', 'K3', 3.00),
    DeliveryZone('الجبيهة', 'K3', 3.00),
    DeliveryZone('الكرسي', 'K3', 3.00),
    DeliveryZone('عرجان', 'K3', 3.00),
    DeliveryZone('المدينة الرياضية', 'K3', 3.00),
    DeliveryZone('السهل', 'K3', 3.00),
    DeliveryZone('السابع', 'K3', 3.00),
    DeliveryZone('الصويفية', 'K3', 3.00),
    
    // K4: 3.50
    DeliveryZone('الرونق', 'K4', 3.50),
    DeliveryZone('البيادر', 'K4', 3.50),
    DeliveryZone('دوار الداخلية', 'K4', 3.50),
    DeliveryZone('العبدلي', 'K4', 3.50),
    DeliveryZone('وادي صقرة', 'K4', 3.50),
    DeliveryZone('مستشفى الإسلامي', 'K4', 3.50),
    DeliveryZone('دير غبار', 'K4', 3.50),
    DeliveryZone('عبدون', 'K4', 3.50),
    DeliveryZone('الحسين', 'K4', 3.50),
    DeliveryZone('جبل عمان', 'K4', 3.50),
    DeliveryZone('أم الأسود', 'K4', 3.50),
    DeliveryZone('أم زويتنة', 'K4', 3.50),
    DeliveryZone('الكمالية', 'K4', 3.50),

    // K5: 4.00
    DeliveryZone('حي المنصور', 'K5', 4.00),
    DeliveryZone('ضاحية الأقصى', 'K5', 4.00),
    DeliveryZone('ضاحية الاستقلال', 'K5', 4.00),
    DeliveryZone('النزهة', 'K5', 4.00),
    DeliveryZone('عين الباشا', 'K5', 4.00),
    DeliveryZone('ضاحية الأمير حسن', 'K5', 4.00),
    DeliveryZone('مستشفى الاستقلال', 'K5', 4.00),
    DeliveryZone('اللويبدة', 'K5', 4.00),
    DeliveryZone('طبربور', 'K5', 4.00),
    DeliveryZone('راس العين', 'K5', 4.00),
    DeliveryZone('شارع الرينبو', 'K5', 4.00),
    DeliveryZone('أبو السوس', 'K5', 4.00),
    DeliveryZone('أم السوس', 'K5', 4.00),
    DeliveryZone('ماحص', 'K5', 4.00),
    DeliveryZone('الفحيص', 'K5', 4.00),
    DeliveryZone('وادي السير', 'K5', 4.00),
    DeliveryZone('صافوط', 'K5', 4.00),

    // K6: 5.00
    DeliveryZone('الياسمين', 'K6', 5.00),
    DeliveryZone('أبو نصير', 'K6', 5.00),
    DeliveryZone('شفا بدران', 'K6', 5.00),
    DeliveryZone('الكوم', 'K6', 5.00),
    DeliveryZone('مرج الحمام', 'K6', 5.00),
    DeliveryZone('إسكان التلفزيون', 'K6', 5.00),
    DeliveryZone('أبو عليا', 'K6', 5.00),
    DeliveryZone('البقعة', 'K6', 5.00),
    DeliveryZone('الهاشمي وسط البلد', 'K6', 5.00),
    DeliveryZone('بدر الجديدة', 'K6', 5.00),
    DeliveryZone('الربحية الشمالية', 'K6', 5.00),
    DeliveryZone('الربحية الجنوبية', 'K6', 5.00),
    DeliveryZone('الأشرفية', 'K6', 5.00),
    DeliveryZone('حي الصحابة', 'K6', 5.00),
    DeliveryZone('رغدان', 'K6', 5.00),

    // K7: 6.00
    DeliveryZone('جبل النصر', 'K7', 6.00),
    DeliveryZone('عدن', 'K7', 6.00),
    DeliveryZone('حي نزال', 'K7', 6.00),
    DeliveryZone('جبل الأخضر', 'K7', 6.00),
    DeliveryZone('المقابلين', 'K7', 6.00),
    DeliveryZone('جبل الزهور', 'K7', 6.00),
    DeliveryZone('البنيات', 'K7', 6.00),
    DeliveryZone('عراق الأمير', 'K7', 6.00),
    DeliveryZone('ضاحية الحاج حسن', 'K7', 6.00),
    DeliveryZone('شارع الحرية', 'K7', 6.00),
    DeliveryZone('المنارة', 'K7', 6.00),
    DeliveryZone('ام النوارة', 'K7', 6.00),
    DeliveryZone('الوحدات', 'K7', 6.00),
    DeliveryZone('ناعور', 'K7', 6.00),

    // K8: 7.00
    DeliveryZone('أبو علندا', 'K8', 7.00),
    DeliveryZone('جاوا', 'K8', 7.00),
    DeliveryZone('الجويدة', 'K8', 7.00),
    DeliveryZone('خريبة السوق', 'K8', 7.00),
    DeliveryZone('ماركا الشمالية', 'K8', 7.00),
    DeliveryZone('ماركا الجنوبية', 'K8', 7.00),
    DeliveryZone('القويسمة', 'K8', 7.00),
    DeliveryZone('اليادودة', 'K8', 7.00),
    DeliveryZone('صالحية العابد', 'K8', 7.00),

    // K9: 9.00
    DeliveryZone('الجبل الشمالي (الرصيفة)', 'K9', 9.00),
    DeliveryZone('سحاب', 'K9', 9.00),
    DeliveryZone('المشيرفة', 'K9', 9.00),
  ];

  @override
  void initState() {
    super.initState();
    deliveryZones.sort((a, b) => a.name.compareTo(b.name));
    final user = StorageService.instance.getCurrentUser();
    if (user != null) {
      customerName = user['name'] ?? '';
      customerPhone = user['phone'] ?? '';
    }
  }

  bool isLoading = false;

  void _confirmOrder() async {
    final l10n = AppLocalizations.of(context)!;
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();

      if (orderType == 'delivery' && selectedZone == null) {
        showCustomSnackbar(context, AppLocalizations.of(context)!.selectZoneError, isSuccess: false);
        return;
      }
      
      setState(() => isLoading = true);

      final cartItems = StorageService.instance.getCart();
      final subtotal = cartItems.fold(0.0, (sum, i) => sum + i.totalPrice);
      
      String finalExtra = '';
      if (orderType == 'delivery') {
        finalExtra = '${l10n.zoneLabel}: ${selectedZone!.name}\n${l10n.streetLabel}: $street - ${l10n.buildingLabel}: $building\n${l10n.notes}: $additionalInfo';
      } else {
        finalExtra = '${l10n.pickupTimeLabel}: ${selectedTime != null ? selectedTime!.format(context) : l10n.asap}\n${l10n.notes}: $additionalInfo';
      }

      final order = OrderModel(
        orderId: 'ORD-${DateTime.now().millisecondsSinceEpoch}',
        timestamp: DateTime.now(),
        customerName: customerName,
        customerPhone: customerPhone,
        orderType: orderType == 'delivery' ? 'delivery' : 'pickup',
        address: orderType == 'delivery' ? '${l10n.zoneLabel}: ${selectedZone!.name}\n${l10n.streetLabel}: $street - ${l10n.buildingLabel}: $building' : null,
        notes: additionalInfo,
        cartItems: cartItems,
        totalPrice: subtotal + (orderType == 'delivery' ? deliveryFee : 0.0),
        subtotal: subtotal,
        deliveryFee: orderType == 'delivery' ? deliveryFee : 0.0,
      );

      try {
        final apiService = ApiService();
        final sentOrder = await apiService.placeOrder(order);

        if (sentOrder == null) {
          throw Exception(l10n.supportError);
        }

        // Save locally for history
        await StorageService.instance.saveOrder(sentOrder);
        await StorageService.instance.clearCart();

        if (mounted) {
          showCustomSnackbar(context, AppLocalizations.of(context)!.orderConfirmedMsg, isSuccess: true);
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const MainNavScreen()),
            (route) => false,
          );
        }
      } catch (e) {
        if (mounted) {
          final errorStr = e.toString().replaceAll('Exception:', '').trim();
          if (errorStr.startsWith('PRICE_CHANGED:')) {
            final msg = errorStr.split('PRICE_CHANGED:')[1].trim();
            showCustomSnackbar(context, msg, isSuccess: false);
          } else {
            showCustomSnackbar(context, '${l10n.supportError}: $errorStr', isSuccess: false);
          }
        }
      } finally {
        if (mounted) setState(() => isLoading = false);
      }
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null && picked != selectedTime) {
      setState(() {
        selectedTime = picked;
      });
    }
  }

  void _showZonesBottomSheet(BuildContext context) {
    String searchQuery = '';
    
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            final filteredZones = deliveryZones.where((zone) {
              return zone.name.toLowerCase().contains(searchQuery.toLowerCase());
            }).toList();

            return Container(
              height: MediaQuery.of(context).size.height * 0.75,
              decoration: BoxDecoration(
                color: Theme.of(context).scaffoldBackgroundColor,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              ),
              child: Column(
                children: [
                   // Handle
                  Container(
                    margin: const EdgeInsets.only(top: 12),
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 12, 12),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          AppLocalizations.of(context)!.selectZoneHint,
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  ),

                  // Search Bar
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).brightness == Brightness.dark 
                            ? Colors.white.withOpacity(0.05) 
                            : Colors.grey[100],
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: TextField(
                        onChanged: (value) {
                          setModalState(() {
                            searchQuery = value;
                          });
                        },
                        decoration: InputDecoration(
                          hintText: AppLocalizations.of(context)!.searchZoneHint,
                          prefixIcon: const Icon(Icons.search, color: Colors.orange),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(vertical: 14),
                          suffixIcon: searchQuery.isNotEmpty 
                            ? IconButton(
                                icon: const Icon(Icons.clear, size: 18),
                                onPressed: () {
                                  setModalState(() {
                                    searchQuery = '';
                                  });
                                },
                              )
                            : null,
                        ),
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 12),
                  const Divider(height: 1),

                  Expanded(
                    child: filteredZones.isEmpty 
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.location_off_outlined, size: 48, color: Colors.grey[400]),
                              const SizedBox(height: 16),
                              Text(
                                AppLocalizations.of(context)!.noZonesFound,
                                style: TextStyle(color: Colors.grey[500], fontSize: 16),
                              ),
                            ],
                          ),
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
                          itemCount: filteredZones.length,
                          separatorBuilder: (context, index) => Divider(
                            height: 1, 
                            indent: 20, 
                            endIndent: 20,
                            color: Colors.grey.withOpacity(0.1),
                          ),
                          itemBuilder: (context, index) {
                            final zone = filteredZones[index];
                            final isSelected = selectedZone?.name == zone.name;

                            return InkWell(
                              onTap: () {
                                setState(() {
                                  selectedZone = zone;
                                  deliveryFee = zone.price;
                                });
                                Navigator.pop(context);
                              },
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                                color: isSelected ? Colors.orange.withOpacity(0.05) : null,
                                child: Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                        color: isSelected ? Colors.orange : Colors.grey.withOpacity(0.1),
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(
                                        Icons.location_on, 
                                        size: 16, 
                                        color: isSelected ? Colors.white : Colors.grey,
                                      ),
                                    ),
                                    const SizedBox(width: 16),
                                    Expanded(
                                      child: Text(
                                        zone.name,
                                        style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                        ),
                                      ),
                                    ),
                                    Text(
                                      '${zone.price.toStringAsFixed(2)} ${AppLocalizations.of(context)!.currency}',
                                      style: TextStyle(
                                        color: Colors.orange,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                      ),
                                      textDirection: TextDirection.rtl,
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final cartItems = StorageService.instance.getCart();
    final subtotal = cartItems.fold(0.0, (sum, i) => sum + i.totalPrice);
    final total = subtotal + (orderType == 'delivery' ? deliveryFee : 0.0);

    return Scaffold(
      appBar: AppBar(title: Text(AppLocalizations.of(context)!.confirmOrder)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Welcome Customer
              Card(
                color: Theme.of(context).primaryColor.withOpacity(0.1),
                elevation: 0,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      const Icon(Icons.person, color: Colors.orange),
                      const SizedBox(width: 12),
                      Text('${AppLocalizations.of(context)!.welcome}، ${customerName.isNotEmpty ? customerName : AppLocalizations.of(context)!.guest}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Order Type
              Text(AppLocalizations.of(context)!.orderTypeLabel, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 8),
              Row(
                children: [
                  _buildOrderTypeChip(AppLocalizations.of(context)!.delivery, 'delivery'),
                  _buildOrderTypeChip(AppLocalizations.of(context)!.takeaway, 'takeaway'),
                ],
              ),

              const SizedBox(height: 16),

              // Dynamic Order Details Content
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextFormField(
                        initialValue: customerName,
                        decoration: InputDecoration(labelText: AppLocalizations.of(context)!.nameLabel, border: const OutlineInputBorder()),
                        validator: (val) => (val == null || val.isEmpty) ? AppLocalizations.of(context)!.nameRequired : null,
                        onSaved: (val) => customerName = val!,
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        initialValue: customerPhone,
                        keyboardType: TextInputType.phone,
                        decoration: InputDecoration(labelText: AppLocalizations.of(context)!.phoneLabel, border: const OutlineInputBorder()),
                        validator: (val) => (val == null || val.isEmpty) ? AppLocalizations.of(context)!.phoneRequired : null,
                        onSaved: (val) => customerPhone = val!,
                      ),
                      const SizedBox(height: 24),
                      
                      const Divider(),
                      const SizedBox(height: 8),

                      if (orderType == 'delivery') ...[
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: Theme.of(context).cardTheme.color,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.04),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                            border: Border.all(color: Colors.grey.withOpacity(0.1)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(AppLocalizations.of(context)!.deliveryAddress, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                                ],
                              ),
                              const SizedBox(height: 16),
                              
                              Text(AppLocalizations.of(context)!.zoneLabel, style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color?.withOpacity(0.7) ?? Colors.grey[700], fontSize: 13, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 8),
                              
                              InkWell(
                                onTap: () => _showZonesBottomSheet(context),
                                borderRadius: BorderRadius.circular(12),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                                  decoration: BoxDecoration(
                                    color: Theme.of(context).brightness == Brightness.dark ? Theme.of(context).scaffoldBackgroundColor : Colors.white,
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(color: Colors.grey.withOpacity(0.2)),
                                  ),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          selectedZone != null ? selectedZone!.name : AppLocalizations.of(context)!.selectZoneHint,
                                          style: TextStyle(
                                            color: selectedZone != null 
                                              ? (Theme.of(context).textTheme.bodyLarge?.color ?? Colors.black)
                                              : Colors.grey[500],
                                            fontSize: 14,
                                          ),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      const Icon(Icons.keyboard_arrow_down, color: Colors.grey),
                                    ],
                                  ),
                                ),
                              ),
                              
                              const SizedBox(height: 16),
                              
                              Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(AppLocalizations.of(context)!.streetLabel, style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color?.withOpacity(0.7) ?? Colors.grey[700], fontSize: 13, fontWeight: FontWeight.bold)),
                                        const SizedBox(height: 8),
                                        TextFormField(
                                          decoration: InputDecoration(
                                            hintText: l10n.streetLabel,
                                            hintStyle: TextStyle(color: Colors.grey[400], fontSize: 14),
                                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey.withOpacity(0.2))),
                                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey.withOpacity(0.2))),
                                            filled: true,
                                            fillColor: Theme.of(context).cardTheme.color,
                                          ),
                                          onSaved: (val) => street = val ?? '',
                                          validator: (val) => orderType == 'delivery' && (val == null || val.isEmpty) ? AppLocalizations.of(context)!.streetLabel : null,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(AppLocalizations.of(context)!.buildingLabel, style: TextStyle(color: Theme.of(context).textTheme.bodyLarge?.color?.withOpacity(0.7) ?? Colors.grey[700], fontSize: 13, fontWeight: FontWeight.bold)),
                                        const SizedBox(height: 8),
                                        TextFormField(
                                          decoration: InputDecoration(
                                            hintText: '${l10n.buildingLabel}...',
                                            hintStyle: TextStyle(color: Colors.grey[400], fontSize: 14),
                                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey.withOpacity(0.2))),
                                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.grey.withOpacity(0.2))),
                                            filled: true,
                                            fillColor: Theme.of(context).cardTheme.color,
                                          ),
                                          onSaved: (val) => building = val ?? '',
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              
                            ],
                          ),
                        ),
                      ],

                      if (orderType == 'takeaway') ...[
                        Text(AppLocalizations.of(context)!.pickupTimeLabel, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        const SizedBox(height: 12),
                        Column(
                          children: [
                            RadioListTile<String>(
                              title: Text(AppLocalizations.of(context)!.asap),
                              value: 'asap',
                              groupValue: pickupTiming,
                              activeColor: Theme.of(context).primaryColor,
                              onChanged: (val) => setState(() => pickupTiming = val!),
                            ),
                            RadioListTile<String>(
                              title: Text(AppLocalizations.of(context)!.atTime),
                              value: 'atTime',
                              groupValue: pickupTiming,
                              activeColor: Theme.of(context).primaryColor,
                              onChanged: (val) => setState(() => pickupTiming = val!),
                            ),
                          ],
                        ),
                        if (pickupTiming == 'atTime')
                          Padding(
                            padding: const EdgeInsets.only(left: 32, right: 16),
                            child: OutlinedButton.icon(
                              onPressed: () => _selectTime(context),
                              icon: const Icon(Icons.access_time),
                              label: Text(selectedTime != null ? selectedTime!.format(context) : AppLocalizations.of(context)!.selectTime),
                            ),
                          ),
                        const SizedBox(height: 16),
                        TextFormField(
                          decoration: InputDecoration(labelText: AppLocalizations.of(context)!.notes, border: const OutlineInputBorder(), hintText: AppLocalizations.of(context)!.notesHint),
                          onSaved: (val) => additionalInfo = val ?? '',
                        ),
                      ],
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // Order Summary Card
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(AppLocalizations.of(context)!.orderSummary, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 12),
                      
                      ...cartItems.map((item) => Padding(
                        padding: const EdgeInsets.only(bottom: 8.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('${item.quantity}x ${item.displayTitle}'),
                            Text('${item.totalPrice.toStringAsFixed(2)} ${AppLocalizations.of(context)!.currency}')
                          ],
                        ),
                      )),
                      
                      const Divider(height: 32),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(AppLocalizations.of(context)!.subtotal),
                          Text('${subtotal.toStringAsFixed(2)} ${AppLocalizations.of(context)!.currency}'),
                        ],
                      ),
                      if (orderType == 'delivery')
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(AppLocalizations.of(context)!.deliveryFee),
                              Text('${deliveryFee.toStringAsFixed(2)} ${AppLocalizations.of(context)!.currency}'),
                            ],
                          ),
                        ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(AppLocalizations.of(context)!.finalTotal, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                          Text('${total.toStringAsFixed(2)} ${AppLocalizations.of(context)!.currency}', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 22, color: Theme.of(context).primaryColor)),
                        ],
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: isLoading ? null : _confirmOrder,
                  style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                  child: isLoading 
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                    : Text(AppLocalizations.of(context)!.confirmOrderNow, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOrderTypeChip(String label, String value) {
    final isSelected = orderType == value;
    return Padding(
      padding: const EdgeInsets.only(left: 12),
      child: ChoiceChip(
        label: Text(label),
        selected: isSelected,
        onSelected: (val) {
          if (val) setState(() => orderType = value);
        },
        selectedColor: Theme.of(context).primaryColor.withOpacity(0.2),
        labelStyle: TextStyle(
          color: isSelected ? Theme.of(context).primaryColor : (Theme.of(context).textTheme.bodyLarge?.color),
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    );
  }
}
