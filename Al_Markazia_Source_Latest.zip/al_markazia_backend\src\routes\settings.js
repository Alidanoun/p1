const express = require('express');
const authenticateToken = require('../middleware/auth');
const { getSettings, updateSetting } = require('../controllers/settingsController');

const router = express.Router();

// Admin only routes
router.get('/', authenticateToken, getSettings);
router.post('/', authenticateToken, updateSetting);

module.exports = router;
