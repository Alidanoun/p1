import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../services/storage_service.dart';
import '../widgets/custom_snackbar.dart';
import 'main_nav_screen.dart';
import '../services/notification_service.dart';
import '../services/api_service.dart';
import '../l10n/generated/app_localizations.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({Key? key}) : super(key: key);

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  
  final _loginFormKey = GlobalKey<FormState>();
  final _regFormKey = GlobalKey<FormState>();

  String loginPhone = '';
  
  String regName = '';
  String regPhone = '';

  bool _isLoginLoading = false;
  bool _isRegLoading = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  void _submitLogin() async {
    if (_loginFormKey.currentState!.validate()) {
      _loginFormKey.currentState!.save();
      
      setState(() => _isLoginLoading = true);
      try {
        final res = await ApiService().loginCustomer(loginPhone);
        await StorageService.instance.setCurrentUser({'name': res['customer']['name'], 'phone': loginPhone});
        NotificationService().init(loginPhone);
        if (mounted) {
          showCustomSnackbar(context, AppLocalizations.of(context)!.loginSuccessMsg);
          _goToHome();
        }
      } catch (e) {
        if (mounted) {
          showCustomSnackbar(context, e.toString().replaceAll('Exception: ', ''), isSuccess: false);
        }
      } finally {
        if (mounted) setState(() => _isLoginLoading = false);
      }
    } else {
      showCustomSnackbar(context, AppLocalizations.of(context)!.fieldsReviewMsg, isSuccess: false);
    }
  }

  void _submitRegister() async {
    if (_regFormKey.currentState!.validate()) {
      _regFormKey.currentState!.save();
      
      setState(() => _isRegLoading = true);
      try {
        final res = await ApiService().registerCustomer(regName, regPhone);
        await StorageService.instance.setCurrentUser({'name': regName, 'phone': regPhone});
        NotificationService().init(regPhone);
        if (mounted) {
          showCustomSnackbar(context, AppLocalizations.of(context)!.registerSuccessMsg);
          _goToHome();
        }
      } catch (e) {
        if (mounted) {
          showCustomSnackbar(context, e.toString().replaceAll('Exception: ', ''), isSuccess: false);
        }
      } finally {
        if (mounted) setState(() => _isRegLoading = false);
      }
    } else {
      showCustomSnackbar(context, AppLocalizations.of(context)!.allFieldsRequiredMsg, isSuccess: false);
    }
  }

  void _goToHome() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const MainNavScreen())
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // Background Color / Pattern
          Container(
            color: Theme.of(context).scaffoldBackgroundColor,
          ),
          
          // Orange Wavy Header
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: ClipPath(
              clipper: TopWaveClipper(),
              child: Container(
                height: MediaQuery.of(context).size.height * 0.45, // Slightly smaller than Welcome screen
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFFDCA965), Color(0xFFB8860B)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Stack(
                  children: [
                    // Textures
                    Positioned(
                      top: -50,
                      right: -30,
                      child: Container(
                        width: 150,
                        height: 150,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white.withOpacity(0.1),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 80,
                      left: -20,
                      child: Container(
                        width: 200,
                        height: 200,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white.withOpacity(0.05), width: 2),
                        ),
                      ),
                    ),
                  ],
                ),
              ).animate().fade(duration: 800.ms).slideY(begin: -0.2, end: 0, curve: Curves.easeOut),
            ),
          ),
          
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Logo Header
                    Container(
                      padding: const EdgeInsets.all(16),
                      margin: const EdgeInsets.only(bottom: 24),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            blurRadius: 15,
                            spreadRadius: 3,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.restaurant_menu_rounded,
                        size: 40,
                        color: Color(0xFFFF6D00),
                      ),
                    ).animate().scale(delay: 200.ms, duration: 600.ms, curve: Curves.easeOutBack),
                    
                    Text(
                      AppLocalizations.of(context)!.loginTitle,
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            color: Colors.black.withOpacity(0.2),
                            offset: const Offset(0, 2),
                            blurRadius: 4,
                          ),
                        ]
                      ),
                    ).animate().fade(delay: 400.ms).slideY(begin: -0.5, end: 0),
                    
                    const SizedBox(height: 32),
                    
                    // Form Card
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 24),
                      child: Card(
                        elevation: 12,
                        shadowColor: Colors.black.withOpacity(0.15),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                        child: Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              TabBar(
                                controller: _tabController,
                                labelColor: const Color(0xFFFF6D00),
                                unselectedLabelColor: Colors.grey.shade400,
                                indicatorColor: const Color(0xFFFF6D00),
                                indicatorWeight: 3,
                                labelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                tabs: [
                                  Tab(text: AppLocalizations.of(context)!.loginTab),
                                  Tab(text: AppLocalizations.of(context)!.registerTab),
                                ],
                              ),
                              const SizedBox(height: 24),
                              
                              SizedBox(
                                height: 320,
                                child: TabBarView(
                                  controller: _tabController,
                                  physics: const BouncingScrollPhysics(),
                                  children: [
                                    // Login Form
                                    Form(
                                      key: _loginFormKey,
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          TextFormField(
                                            keyboardType: TextInputType.phone,
                                            decoration: InputDecoration(
                                              labelText: AppLocalizations.of(context)!.phoneLabel.split(' (')[0],
                                              prefixIcon: const Icon(Icons.phone_rounded, color: Color(0xFFFF6D00)),
                                              filled: true,
                                              fillColor: Colors.grey.shade50,
                                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                                            ),
                                            validator: (val) => (val == null || val.isEmpty) ? AppLocalizations.of(context)!.required : null,
                                            onSaved: (val) => loginPhone = val!,
                                          ),
                                          const SizedBox(height: 32),
                                          SizedBox(
                                            width: double.infinity,
                                            height: 56,
                                            child: ElevatedButton(
                                              onPressed: _isLoginLoading ? null : _submitLogin,
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: const Color(0xFFFF6D00),
                                                foregroundColor: Colors.white,
                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                                elevation: 8,
                                                shadowColor: const Color(0xFFFF6D00).withOpacity(0.5),
                                              ),
                                              child: _isLoginLoading 
                                                ? const CircularProgressIndicator(color: Colors.white)
                                                : Text(AppLocalizations.of(context)!.loginTab, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    
                                    // Register Form
                                    Form(
                                      key: _regFormKey,
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          TextFormField(
                                            decoration: InputDecoration(
                                              labelText: AppLocalizations.of(context)!.fullNameLabel,
                                              prefixIcon: const Icon(Icons.person_rounded, color: Color(0xFFFF6D00)),
                                              filled: true,
                                              fillColor: Colors.grey.shade50,
                                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                                            ),
                                            validator: (val) => (val == null || val.isEmpty) ? AppLocalizations.of(context)!.required : null,
                                            onSaved: (val) => regName = val!,
                                          ),
                                          const SizedBox(height: 16),
                                          TextFormField(
                                            keyboardType: TextInputType.phone,
                                            decoration: InputDecoration(
                                              labelText: AppLocalizations.of(context)!.phoneLabel.split(' (')[0],
                                              prefixIcon: const Icon(Icons.phone_rounded, color: Color(0xFFFF6D00)),
                                              filled: true,
                                              fillColor: Colors.grey.shade50,
                                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                                            ),
                                            validator: (val) => (val == null || val.isEmpty) ? AppLocalizations.of(context)!.required : null,
                                            onSaved: (val) => regPhone = val!,
                                          ),
                                          const SizedBox(height: 32),
                                          SizedBox(
                                            width: double.infinity,
                                            height: 56,
                                            child: ElevatedButton(
                                              onPressed: _isRegLoading ? null : _submitRegister,
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: const Color(0xFFFF6D00),
                                                foregroundColor: Colors.white,
                                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                                                elevation: 8,
                                                shadowColor: const Color(0xFFFF6D00).withOpacity(0.5),
                                              ),
                                              child: _isRegLoading
                                                ? const CircularProgressIndicator(color: Colors.white)
                                                : Text(AppLocalizations.of(context)!.registerAction, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ).animate().fade(delay: 600.ms).slideY(begin: 0.2, end: 0, curve: Curves.easeOutBack),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Custom Clipper for the Wavy Header (reused from WelcomeScreen, but placed here since files are separate)
class TopWaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    var path = Path();
    path.lineTo(0, size.height - 80);
    
    var firstControlPoint = Offset(size.width / 4, size.height);
    var firstEndPoint = Offset(size.width / 2.25, size.height - 30);
    path.quadraticBezierTo(
      firstControlPoint.dx, firstControlPoint.dy, 
      firstEndPoint.dx, firstEndPoint.dy
    );
    
    var secondControlPoint = Offset(size.width - (size.width / 3.25), size.height - 90);
    var secondEndPoint = Offset(size.width, size.height - 40);
    path.quadraticBezierTo(
      secondControlPoint.dx, secondControlPoint.dy, 
      secondEndPoint.dx, secondEndPoint.dy
    );
    
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
