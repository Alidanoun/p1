const express = require('express');
const authenticateToken = require('../middleware/auth');
const upload = require('../middleware/upload');
const { getAllItems, createItem, updateItem, deleteItem, updateFeaturedItems } = require('../controllers/itemController');

const router = express.Router();

router.get('/', getAllItems);
router.post('/', authenticateToken, upload.single('image'), createItem);
router.put('/featured', authenticateToken, updateFeaturedItems);
router.put('/:id', authenticateToken, upload.single('image'), updateItem);
router.patch('/:id/options/toggle', authenticateToken, (req, res, next) => {
  // New specific endpoint for availability toggling to avoid "wipe and rebuild" complexity
  require('../controllers/itemController').toggleOptionAvailability(req, res, next);
});
router.delete('/:id', authenticateToken, deleteItem);

module.exports = router;
