import { useState, useEffect } from 'react';
import { ShoppingBag, TrendingUp, DollarSign, Clock, Activity, RefreshCw, BarChart3, Star, Award, TrendingDown, Target, Zap, X, Search, CheckCircle2 } from 'lucide-react';
import Header from '../components/Header';
import api, { getImageUrl } from '../api/client';
import { AnimatePresence, motion } from 'framer-motion';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { formatCurrencyArabic, formatNumberArabic } from '../lib/formatters';
import { cn } from '../lib/utils';
import Switch from '../components/Switch';
import { toast } from 'sonner';


// eslint-disable-next-line no-unused-vars
const KPICard = ({ title, value, icon, colorClass, delay, showTrend = false, percentage, isPositive }) => { 
  const Icon = icon; 
  
  const colorMap = {
    'primary': { text: 'text-primary', bg: 'bg-primary', via: 'via-primary/50' },
    'emerald-500': { text: 'text-emerald-500', bg: 'bg-emerald-500', via: 'via-emerald-500/50' },
    'amber-500': { text: 'text-amber-500', bg: 'bg-amber-500', via: 'via-amber-500/50' },
    'purple-500': { text: 'text-purple-500', bg: 'bg-purple-500', via: 'via-purple-500/50' },
  };
  const colors = colorMap[colorClass] || colorMap['primary'];
  
  return (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.5, type: 'spring' }}
    whileHover={{ y: -5 }}
    className="bg-card/60 backdrop-blur-xl p-6 rounded-3xl border border-white/5 shadow-xl relative overflow-hidden group"
  >
    <div className={cn(
      "absolute inset-x-0 -top-px h-px w-full bg-gradient-to-r from-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500",
      colors.via
    )} />
    
    <div className="flex justify-between items-start mb-5 text-right" dir="rtl">
      <div className={cn(
        "p-4 rounded-2xl bg-background border border-white/5 shadow-inner transition-transform group-hover:scale-110 duration-300",
        colors.text
      )}>
        <Icon className="w-6 h-6" />
      </div>
      {showTrend && percentage && (
        <div className={cn(
          "flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-lg border border-white/5",
          isPositive ? "text-emerald-500 bg-emerald-500/10" : "text-red-500 bg-red-500/10"
        )}>
          {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
          <span dir="ltr">{percentage}%</span>
        </div>
      )}
    </div>
    
    <div className="text-right">
      <h3 className="text-text-muted font-bold text-xs uppercase tracking-widest mb-2 opacity-70">{title}</h3>
      <p className="text-3xl font-bold font-mono text-white tracking-tight">{value}</p>
    </div>
    
    <div className={cn(
      "absolute bottom-0 right-0 w-24 h-24 blur-3xl rounded-full opacity-10 -mr-12 -mb-12",
      colors.bg
    )} />
  </motion.div>
); };

const Dashboard = () => {
  const [timeRange, setTimeRange] = useState('day'); 
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [stats, setStats] = useState({ orders: 0, revenue: 0, activeOrders: 0, topItem: 'جاري التحميل...' });
  const [recentOrders, setRecentOrders] = useState([]);
  const [chartData, setChartData] = useState([]);
  const [topItems, setTopItems] = useState([]);
  const [prevTopIds, setPrevTopIds] = useState(''); // Tracking for sync optimization
  
  // Analytics & Manual Selection Logic - Persisted in localStorage
  const [isAutoTopItems, setIsAutoTopItems] = useState(
    () => localStorage.getItem('dash_isAutoTopItems') !== 'false'
  );
  const [autoThreshold, setAutoThreshold] = useState(
    () => parseInt(localStorage.getItem('dash_autoThreshold') || '20', 10)
  );
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);
  const [allItems, setAllItems] = useState([]);
  const [manualSelectedIds, setManualSelectedIds] = useState(
    () => JSON.parse(localStorage.getItem('dash_manualSelectedIds') || '[]')
  );
  const [excludedAutoIds, setExcludedAutoIds] = useState(
    () => JSON.parse(localStorage.getItem('dash_excludedAutoIds') || '[]')
  );
  const [deleteConfirmItem, setDeleteConfirmItem] = useState(null);
  const [searchManual, setSearchManual] = useState('');

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000); 
    return () => clearInterval(interval);
  }, [timeRange, isAutoTopItems, manualSelectedIds]); // eslint-disable-line react-hooks/exhaustive-deps

  const fetchData = async () => {
    try {
      const [ordersRes, itemsRes] = await Promise.all([
        api.get(`/orders?time_range=${timeRange}`),
        api.get('/items?admin=true')
      ]);
      
      const orders = ordersRes.data || [];
      const menuItems = itemsRes.data || [];
      setAllItems(menuItems);

      // Pre-fill manual selection from DB if we haven't already
      if (manualSelectedIds.length === 0) {
        const dbFeaturedIds = menuItems.filter(i => i.isFeatured).map(i => i.id);
        if (dbFeaturedIds.length > 0) {
          setManualSelectedIds(dbFeaturedIds);
        }
      }
      
      const now = new Date();
      setLastUpdated(now);

      let filteredOrders = orders;
      const todayStart = new Date().setHours(0,0,0,0);
      
      if (timeRange === 'day') {
        filteredOrders = orders.filter(o => new Date(o.createdAt).getTime() >= todayStart);
      } else if (timeRange === 'week') {
        const weekAgo = new Date();
        weekAgo.setDate(weekAgo.getDate() - 7);
        filteredOrders = orders.filter(o => new Date(o.createdAt) >= weekAgo);
      } else if (timeRange === 'month') {
        const monthAgo = new Date();
        monthAgo.setMonth(monthAgo.getMonth() - 1);
        filteredOrders = orders.filter(o => new Date(o.createdAt) >= monthAgo);
      }

      const totalRevenue = filteredOrders.reduce((sum, order) => sum + (order.subtotal || 0), 0);
      const activeOrders = orders.filter(o => ['pending', 'preparing', 'ready'].includes(o.status)).length;
      
      let calculatedTopItems = [];

      if (isAutoTopItems) {
        // Automatic logic: Group by itemId and use GLOBAL orders (as requested)
        const itemCounts = {};
        orders.forEach(order => {
          if (order.orderItems && Array.isArray(order.orderItems)) {
            order.orderItems.forEach(item => {
              const itemId = item.itemId;
              if (!itemId) return; // Skip items without ID (old data or errors)
              
              if (!itemCounts[itemId]) {
                itemCounts[itemId] = { 
                  originalId: itemId, 
                  name: item.itemName || item.title || 'صنف غير معروف', 
                  orders: 0, 
                  revenue: 0 
                };
              }
              itemCounts[itemId].orders += (item.quantity || item.qty || 1);
              itemCounts[itemId].revenue += (parseFloat(item.unitPrice) || parseFloat(item.price) || 0) * (item.quantity || item.qty || 1);
            });
          }
        });

        calculatedTopItems = Object.values(itemCounts)
          .filter(item => item.orders >= autoThreshold)
          .filter(item => !excludedAutoIds.includes(item.originalId))
          .sort((a, b) => b.orders - a.orders)
          .slice(0, 5)
          .map((item, idx) => ({ ...item, id: idx + 1, trend: 'مستقر' }));
          
        // Optimized Auto-sync: Only if the list of ID has changed
        const currentIdsJson = JSON.stringify(calculatedTopItems.map(i => i.originalId));
        if (calculatedTopItems.length > 0 && currentIdsJson !== prevTopIds) {
           api.put('/items/featured', { itemIds: calculatedTopItems.map(i => i.originalId) })
             .then(() => setPrevTopIds(currentIdsJson))
             .catch(e => console.error(e));
        }
      } else {
        // Manual logic: Fetch REAL global stats for manually selected items
        const itemCounts = {};
        orders.forEach(order => {
          if (order.orderItems && Array.isArray(order.orderItems)) {
            order.orderItems.forEach(item => {
              const itemId = item.itemId;
              if (itemId && manualSelectedIds.includes(itemId)) {
                if (!itemCounts[itemId]) {
                  itemCounts[itemId] = { orders: 0, revenue: 0 };
                }
                itemCounts[itemId].orders += (item.quantity || item.qty || 1);
                itemCounts[itemId].revenue += (parseFloat(item.unitPrice) || parseFloat(item.price) || 0) * (item.quantity || item.qty || 1);
              }
            });
          }
        });

        calculatedTopItems = menuItems
          .filter(item => manualSelectedIds.includes(item.id))
          .map((item, idx) => ({
            id: idx + 1,
            originalId: item.id,
            name: item.title,
            orders: itemCounts[item.id]?.orders || 0, 
            revenue: itemCounts[item.id]?.revenue || 0,
            trend: 'يدوي'
          }))
          .sort((a, b) => b.orders - a.orders); // Sort by real popularity even in manual
      }

      setTopItems(calculatedTopItems);

      setStats({
        orders: filteredOrders.length,
        revenue: totalRevenue,
        activeOrders: activeOrders,
        topItem: calculatedTopItems[0]?.name || 'لا بيانات كافية'
      });
      
      setRecentOrders(orders.slice(0, 6));

      // Enhanced Real-Data Chart Logic
      let dynamicChart = [];
      const chartNow = new Date();

      if (timeRange === 'day') {
        // Today's orders only, filtered by hour (08:00 - 23:00)
        const todayStart = new Date(chartNow).setHours(0, 0, 0, 0);
        const dayOrders = orders.filter(o => new Date(o.createdAt).getTime() >= todayStart);
        
        for (let h = 8; h <= 23; h++) {
          const label = `${h.toString().padStart(2, '0')}:00`;
          const hourSales = dayOrders.reduce((sum, order) => {
            const orderDate = new Date(order.createdAt);
            return orderDate.getHours() === h ? sum + (order.subtotal || 0) : sum;
          }, 0);
          dynamicChart.push({ name: label, مبيعات: hourSales });
        }
      } else if (timeRange === 'week') {
        // Week starts from Saturday (السبت) to Friday (الجمعة)
        const orderedArabicDays = ['السبت', 'الأحد', 'الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'];
        
        // Find the most recent Saturday
        // JS getDay(): 0=Sun, 1=Mon, 2=Tue, 3=Wed, 4=Thu, 5=Fri, 6=Sat
        const currentDayIndex = chartNow.getDay(); 
        const daysSinceSaturday = (currentDayIndex === 6) ? 0 : currentDayIndex + 1;
        const saturday = new Date(chartNow);
        saturday.setDate(chartNow.getDate() - daysSinceSaturday);
        saturday.setHours(0, 0, 0, 0);

        dynamicChart = orderedArabicDays.map((dayName, idx) => {
          const dayDate = new Date(saturday);
          dayDate.setDate(saturday.getDate() + idx);
          
          const daySales = orders.reduce((sum, order) => {
            const oDate = new Date(order.createdAt);
            const isSameDay = oDate.getDate() === dayDate.getDate() && 
                             oDate.getMonth() === dayDate.getMonth() && 
                             oDate.getFullYear() === dayDate.getFullYear();
            return isSameDay ? sum + (order.subtotal || 0) : sum;
          }, 0);
          
          return { name: dayName, مبيعات: daySales };
        });
      } else if (timeRange === 'month') {
        // Current month days (1st to 28/29/30/31)
        const year = chartNow.getFullYear();
        const month = chartNow.getMonth();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        for (let d = 1; d <= daysInMonth; d++) {
          const daySales = orders.reduce((sum, order) => {
            const oDate = new Date(order.createdAt);
            const isSameDay = oDate.getDate() === d && 
                             oDate.getMonth() === month && 
                             oDate.getFullYear() === year;
            return isSameDay ? sum + (order.subtotal || 0) : sum;
          }, 0);
          dynamicChart.push({ name: d.toString(), مبيعات: daySales });
        }
      }
      setChartData(dynamicChart);
    } catch (err) {
      console.error('Failed to load dashboard data', err);
    }
  };
  
  const handleDeleteTopItem = (item) => {
    setDeleteConfirmItem(item);
  };

  const confirmDelete = () => {
    if (!deleteConfirmItem) return;
    const item = deleteConfirmItem;

    if (isAutoTopItems) {
      if (item.originalId) {
        const updated = [...excludedAutoIds, item.originalId];
        setExcludedAutoIds(updated);
        localStorage.setItem('dash_excludedAutoIds', JSON.stringify(updated));
        toast.success(`تم إبعاد ${item.name} من القائمة التلقائية`);
      }
    } else {
      const updated = manualSelectedIds.filter(id => id !== item.originalId);
      setManualSelectedIds(updated);
      localStorage.setItem('dash_manualSelectedIds', JSON.stringify(updated));
      toast.info(`تم حذف ${item.name} من القائمة اليدوية`);
    }
    setDeleteConfirmItem(null);
  };

  const resetAutomaticExclusions = () => {
    setExcludedAutoIds([]);
    localStorage.removeItem('dash_excludedAutoIds');
    toast.success('تمت إعادة تعيين القائمة التلقائية بالكامل');
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000); 
    return () => clearInterval(interval);
  }, [timeRange, isAutoTopItems, manualSelectedIds]); // eslint-disable-line react-hooks/exhaustive-deps

  const toggleManualId = (id) => {
    let updated;
    if (manualSelectedIds.includes(id)) {
      updated = manualSelectedIds.filter(i => i !== id);
    } else {
      if (manualSelectedIds.length >= 5) {
        toast.warning('يمكنك اختيار بحد أقصى 5 أصناف يدوياً');
        return;
      }
      updated = [...manualSelectedIds, id];
    }
    setManualSelectedIds(updated);
    localStorage.setItem('dash_manualSelectedIds', JSON.stringify(updated));
  };

  const statusColors = {
    pending: 'bg-amber-500/20 text-amber-500 border-amber-500/20',
    preparing: 'bg-blue-500/20 text-blue-500 border-blue-500/20',
    ready: 'bg-emerald-500/20 text-emerald-500 border-emerald-500/20',
    delivered: 'bg-slate-500/20 text-slate-400 border-slate-500/20',
    cancelled: 'bg-red-500/20 text-red-500 border-red-500/20'
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4 md:p-8 max-w-[1600px] mx-auto min-h-screen pb-20 text-right" dir="rtl">
      <Header title="لوحة التحكم التنفيذية" subtitle="مراقب الأداء الذكي والتحليلات المتقدمة" />

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10 mt-[-1rem]">
        <div className="flex bg-card/60 p-1.5 rounded-2xl border border-white/5 backdrop-blur-lg shadow-xl shrink-0">
          {['day', 'week', 'month'].map((id) => (
            <button key={id} onClick={() => setTimeRange(id)} className={cn("px-8 py-2 rounded-xl text-xs font-bold transition-all duration-300 relative overflow-hidden", timeRange === id ? "text-white shadow-lg bg-primary scale-[1.05]" : "text-text-muted hover:text-white")}>
              {id === 'day' ? 'اليوم' : id === 'week' ? 'الأسبوع' : 'الشهر'}
              {timeRange === id && <motion.div layoutId="activeTab" className="absolute inset-0 bg-primary -z-10" />}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-[10px] font-bold text-text-muted bg-card/60 px-4 py-2 rounded-xl border border-white/5 backdrop-blur-md shadow-sm">
            <Clock className="w-3.5 h-3.5 text-primary animate-pulse" />
            <span className="opacity-60">آخر تحديث:</span>
            <span className="text-white font-mono" dir="ltr">{lastUpdated.toLocaleTimeString('en-US')}</span>
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-4 py-2 rounded-xl border border-emerald-500/10 backdrop-blur-md">
            <RefreshCw className="w-3.5 h-3.5 animate-spin-slow" />
            <span>تحديث مفعّل</span>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <KPICard title="إجمالي المبيعات" value={formatCurrencyArabic(stats.revenue)} icon={DollarSign} colorClass="primary" delay={0.1} />
        <KPICard title="إجمالي الطلبات" value={formatNumberArabic(stats.orders)} icon={ShoppingBag} colorClass="emerald-500" delay={0.2} />
        <KPICard title="الطلبات النشطة" value={formatNumberArabic(stats.activeOrders)} icon={Activity} colorClass="amber-500" delay={0.3} />
        <KPICard title="الأعلى مبيعاً" value={stats.topItem} icon={Star} colorClass="purple-500" delay={0.4} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 mb-10 text-right">
        <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="xl:col-span-2 bg-card/60 backdrop-blur-xl p-8 rounded-[2rem] border border-white/5 shadow-2xl flex flex-col relative group">
          <div className="flex items-center justify-between mb-10">
             <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-3">
              {timeRange === 'day' ? 'تحليل المبيعات اليومي (08:00 - 23:00)' : 
               timeRange === 'week' ? 'تحليل المبيعات الأسبوعي (السبت - الجمعة)' : 
               'تحليل المبيعات الشهري'}
             </h2>
          </div>
          <div className="h-[350px] w-full" dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 20, right: 30, left: 10, bottom: 0 }}>
                <defs><linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#f97316" stopOpacity={0.4}/><stop offset="95%" stopColor="#f97316" stopOpacity={0}/></linearGradient></defs>
                <CartesianGrid strokeDasharray="5 5" stroke="#334155" vertical={false} opacity={0.3} />
                <XAxis 
                  dataKey="name" 
                  stroke="#94a3b8" 
                  fontSize={11} 
                  tickLine={false} 
                  axisLine={false} 
                  dy={15} 
                  interval={timeRange === 'month' ? 4 : 0}
                />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} axisLine={false} tickFormatter={(v) => formatNumberArabic(v)} dx={-10} />
                <Tooltip cursor={{ stroke: '#f97316', strokeWidth: 2, strokeDasharray: '5 5' }} contentStyle={{ backgroundColor: '#0f172a', borderColor: 'rgba(255,255,255,0.05)', borderRadius: '20px' }} itemStyle={{ color: '#f97316', fontWeight: 'bold' }} formatter={(v) => [formatCurrencyArabic(v), 'المبيعات']} />
                <Area type="monotone" dataKey="مبيعات" stroke="#f97316" strokeWidth={4} fillOpacity={1} fill="url(#colorSales)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} className="bg-card/60 backdrop-blur-xl p-8 rounded-[2rem] border border-white/5 shadow-2xl flex flex-col">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-3"><Award className="w-6 h-6 text-primary" /> الأكثر طلباً</h2>
            <div className="flex items-center gap-2">
               {isAutoTopItems && (
                 <input 
                   type="number"
                   value={autoThreshold}
                   onChange={e => {
                     const val = Number(e.target.value);
                     setAutoThreshold(val);
                     localStorage.setItem('dash_autoThreshold', val);
                   }}
                   className="w-14 h-6 text-center text-[10px] font-bold bg-white/5 border border-white/10 rounded-md text-white outline-none focus:border-primary"
                   min="1"
                   title="الحد الأدنى للطلبات"
                 />
               )}
               <span className="text-[9px] font-bold text-text-muted uppercase">ذكي {isAutoTopItems ? `(>${autoThreshold})` : '(يدوي)'}</span>
               <Switch checked={isAutoTopItems} onChange={(val) => {
                 setIsAutoTopItems(val);
                 localStorage.setItem('dash_isAutoTopItems', val);
               }} />
               {isAutoTopItems && excludedAutoIds.length > 0 && (
                 <button 
                  onClick={resetAutomaticExclusions}
                  className="text-[9px] font-bold text-primary hover:underline"
                  title="إعادة التلقائي"
                 >
                   إعادة تعيين
                 </button>
               )}
            </div>
          </div>
          
          <div className="space-y-4 flex-1">
            {topItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-10 h-full border-2 border-dashed border-white/5 rounded-3xl opacity-20 text-center">
                    <Target className="w-10 h-10 mb-4" />
                    <p className="text-xs font-bold">لا يوجد أصناف حالياً <br/> {isAutoTopItems ? `(أقل من ${autoThreshold} مبيعاً)` : '(لم تضف أصناف يدوياً)'}</p>
                </div>
            ) : topItems.map((item, index) => (
              <div key={item.id} className="group flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 transition-all duration-300">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-xl bg-background border border-white/5 flex items-center justify-center text-primary font-bold text-sm">{index + 1}</div>
                  <div><h4 className="text-white font-bold text-sm mb-0.5 mt-[-2px]">{item.name}</h4><p className="text-text-muted text-[10px] font-bold uppercase tracking-wider">{item.orders} طلب</p></div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-primary font-bold text-sm mb-0.5">{formatCurrencyArabic(item.revenue)}</p>
                    <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-full border", item.trend.startsWith('+') ? "text-emerald-500 border-emerald-500/20 bg-emerald-500/5" : "text-red-500 border-red-500/20 bg-red-500/5")}>{item.trend}</span>
                  </div>
                  <button 
                    onClick={() => handleDeleteTopItem(item)}
                    className="p-2 rounded-xl bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white transition-all opacity-0 group-hover:opacity-100"
                    title="حذف من القائمة"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {!isAutoTopItems && (
             <button onClick={() => setIsManualModalOpen(true)} className="mt-6 w-full py-3 rounded-xl bg-primary/10 border border-primary/20 text-primary text-[10px] font-black uppercase hover:bg-primary hover:text-white transition-all shadow-lg shadow-primary/10">إضافة أصناف يدوياً للقائمة</button>
          )}
        </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pb-12">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-card/40 backdrop-blur-xl p-8 rounded-[2rem] border border-white/5">
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-3 mb-8"><Clock className="w-6 h-6 text-primary" /> أحدث الطلبات</h2>
          <div className="overflow-x-auto overflow-hidden">
            <table className="w-full text-right" dir="rtl">
              <thead><tr className="text-text-muted text-[10px] font-bold uppercase tracking-widest border-b border-white/5"><th className="pb-4 pr-2">رقم الطلب</th><th className="pb-4">العميل</th><th className="pb-4">المبلغ</th><th className="pb-4 pl-2 text-center">الحالة</th></tr></thead>
              <tbody className="text-sm">
                {recentOrders.map((order) => (
                  <tr key={order.id} className="group border-b border-white/5 last:border-0 hover:bg-white/[0.02]"><td className="py-4 pr-2 text-white font-mono font-bold">#{order.orderId?.substring(0, 6)}</td><td className="py-4 text-text-muted font-bold truncate max-w-[120px]">{order.customerName}</td><td className="py-4 text-white font-bold">{formatCurrencyArabic(order.subtotal)}</td><td className="py-4 pl-2 text-center"><div className={cn("mx-auto w-fit text-[10px] font-bold px-3 py-1 rounded-full border shadow-sm", statusColors[order.status] || statusColors.pending)}>{order.status === 'pending' ? 'انتظار' : order.status === 'preparing' ? 'تجهيز' : order.status === 'ready' ? 'جاهز' : order.status === 'delivered' ? 'توصيل' : 'ملغي'}</div></td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-gradient-to-br from-primary/20 to-card/60 p-8 rounded-[2rem] border border-primary/10 relative overflow-hidden group">
           <div className="relative z-10 text-right" dir="rtl">
              <div className="flex items-center gap-4 mb-6"><div className="p-3 bg-primary rounded-2xl text-white shadow-xl"><BarChart3 className="w-6 h-6" /></div><h2 className="text-xl font-bold text-white tracking-tight">ملخص الأداء اليومي</h2></div>
              <p className="text-text-muted text-sm mb-10 max-w-sm leading-relaxed">أداء المطعم اليوم ممتاز، المبيعات متقاربة مع الأسبوع الماضي مع زيادة طفيفة في الطلبات النشطة.</p>
              <div className="grid grid-cols-2 gap-4"><div className="bg-background/40 backdrop-blur-md p-5 rounded-2xl border border-white/5"><p className="text-[10px] text-text-muted uppercase font-bold mb-1 tracking-widest">متوسط الوقت</p><p className="text-white font-bold text-lg">18 دقيقة</p></div><div className="bg-background/40 backdrop-blur-md p-5 rounded-2xl border border-white/5"><p className="text-[10px] text-text-muted uppercase font-bold mb-1 tracking-widest">حالة النظام</p><div className="flex items-center gap-2 justify-end"><span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" /><p className="text-white font-bold text-sm">متصل</p></div></div></div>
           </div>
        </motion.div>
      </div>

      {/* Manual Selection Modal */}
      <AnimatePresence>
        {isManualModalOpen && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setIsManualModalOpen(false)} className="absolute inset-0 bg-background/95 backdrop-blur-2xl" />
            <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }} className="relative w-full max-w-2xl bg-[#0B0F19] rounded-[40px] border border-white/10 shadow-3xl overflow-hidden flex flex-col max-h-[85vh]">
               <div className="p-8 pb-0 flex items-center justify-between mb-8">
                  <div><h2 className="text-2xl font-black text-white">اختر الأصناف الأكثر مبيعاً</h2><p className="text-text-muted text-xs mt-1">اختر حتى 5 أصناف ليتم عرضها في لوحة التحكم يدوياً</p></div>
                  <button onClick={() => setIsManualModalOpen(false)} className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10"><X className="w-5 h-5 text-white" /></button>
               </div>
               <div className="px-8 mb-6 relative">
                  <Search className="absolute right-12 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
                  <input type="text" placeholder="ابحث عن صنف..." className="glass-input pr-12 h-12 text-sm" value={searchManual} onChange={e => setSearchManual(e.target.value)} />
               </div>
               <div className="flex-1 overflow-y-auto px-8 pb-10 space-y-3 scrollbar-hide">
                  {allItems.filter(i => i.title.toLowerCase().includes(searchManual.toLowerCase())).map((item) => {
                    const isSelected = manualSelectedIds.includes(item.id);
                    return (
                      <div key={item.id} onClick={() => toggleManualId(item.id)} className={cn("p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between group", isSelected ? "bg-primary/10 border-primary/30" : "bg-white/5 border-white/5 hover:bg-white/10")}>
                        <div className="flex items-center gap-4">
                           <div className="w-12 h-12 rounded-xl bg-slate-900 border border-white/5 overflow-hidden">
                              {item.image ? <img src={getImageUrl(item.image)} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center opacity-20"><Target className="w-5 h-5" /></div>}
                           </div>
                           <div className="text-right"><h4 className="font-bold text-white text-sm">{item.title}</h4><p className="text-[10px] text-text-muted font-mono">{Number(item.basePrice || 0).toFixed(2)} JOD</p></div>
                        </div>
                        {isSelected ? <CheckCircle2 className="w-6 h-6 text-primary" /> : <div className="w-6 h-6 rounded-full border-2 border-white/10 group-hover:border-white/20 transition-all" />}
                      </div>
                    );
                  })}
               </div>
               <div className="p-8 border-t border-white/5 bg-black/20 flex justify-between items-center">
                  <div className="text-xs font-bold text-text-muted">تم اختيار: <span className="text-primary">{manualSelectedIds.length} / 5</span></div>
                  <button onClick={() => { 
                    setIsManualModalOpen(false); 
                    api.put('/items/featured', { itemIds: manualSelectedIds }).catch(e => console.error(e));
                  }} className="px-10 py-3 bg-primary text-white font-black rounded-2xl shadow-xl shadow-primary/20">حفظ التغييرات</button>
               </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Custom Delete Confirmation Modal */}
      <AnimatePresence>
        {deleteConfirmItem && (
          <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setDeleteConfirmItem(null)} className="absolute inset-0 bg-background/90 backdrop-blur-md" />
            <motion.div initial={{ opacity: 0, scale: 0.95, y: 20 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.95, y: 20 }} className="relative w-full max-w-sm bg-card border border-white/10 p-8 rounded-[2.5rem] shadow-3xl text-center">
              <div className="w-16 h-16 bg-red-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <X className="w-8 h-8 text-red-500" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">تأكيد الحذف</h3>
              <p className="text-text-muted text-sm mb-8 leading-relaxed">هل أنت متأكد من حذف الصنف <span className="text-white font-bold">"{deleteConfirmItem.name}"</span> من قائمة الأكثر طلباً؟</p>
              
              <div className="grid grid-cols-2 gap-4">
                 <button onClick={() => setDeleteConfirmItem(null)} className="py-3 px-6 rounded-2xl bg-white/5 border border-white/10 text-white font-bold text-sm hover:bg-white/10 transition-all">إلغاء</button>
                 <button onClick={confirmDelete} className="py-3 px-6 rounded-2xl bg-red-500 text-white font-bold text-sm shadow-lg shadow-red-500/20 hover:bg-red-600 transition-all">نعم، حذف</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default Dashboard;
