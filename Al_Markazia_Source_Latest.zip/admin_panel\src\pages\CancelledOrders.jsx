import { useState, useEffect } from 'react';
import { XCircle, User, Calendar, Clock, AlertTriangle, Hash, ShieldCheck } from 'lucide-react';
import Header from '../components/Header';
import api from '../api/client';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { cn } from '../lib/utils';

const CancelledOrders = () => {
  const [cancellations, setCancellations] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchCancellations = async () => {
    try {
      // In a real app, I'd create a specific endpoint for cancellations.
      // For now, I'll fetch orders with status 'cancelled' and include the cancellation model.
      const { data } = await api.get('/orders?time_range=month');
      // The backend returns mapped objects. I need to ensure cancellation data is present.
      // Since I added the cancellation model to Prisma, I should fetch it.
      // Filter for cancelled orders only.
      const cancelledOnes = data.filter(o => o.status === 'cancelled');
      setCancellations(cancelledOnes);
      setLoading(false);
    } catch (error) {
      console.error('Failed to fetch cancellations', error);
      setLoading(false);
    }
  };

  const calculateStats = () => {
    if (cancellations.length === 0) return { totalLoss: 0, topReason: 'N/A', customerCount: 0 };
    
    const totalLoss = cancellations.reduce((acc, order) => {
      // Logic: total - deliveryFee
      return acc + (order.total - (order.deliveryFee || 0));
    }, 0);

    const customerCount = cancellations.filter(o => o.cancellation?.cancelledBy === 'customer').length;
    const adminCount = cancellations.filter(o => o.cancellation?.cancelledBy === 'admin').length;

    return { totalLoss, customerCount, adminCount };
  };

  useEffect(() => {
    fetchCancellations();
  }, []);

  const stats = calculateStats();

  const getStatusBadge = (status) => {
    const statuses = {
      'pending': { label: 'قيد الانتظار', color: 'text-amber-500 bg-amber-500/10' },
      'preparing': { label: 'قيد التجهيز', color: 'text-blue-500 bg-blue-500/10' },
      'ready': { label: 'جاهز للاستلام', color: 'text-purple-500 bg-purple-500/10' },
      'in_route': { label: 'في الطريق', color: 'text-orange-500 bg-orange-500/10' },
    };
    const s = statuses[status] || { label: status, color: 'text-white bg-white/10' };
    return <span className={cn("px-2 py-0.5 rounded-full text-[10px] font-bold", s.color)}>{s.label}</span>;
  };

  return (
    <div className="p-4 md:p-8 max-w-[1600px] mx-auto min-h-screen">
      <Header 
        title="الطلبات الملغاة" 
        subtitle="أرشيف كامل للطلبات التي تم إلغاؤها وأسباب الإلغاء" 
      />

      {/* Stats Board */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
         <div className="bg-card/40 backdrop-blur-md rounded-2xl border border-white/5 p-6 border-r-4 border-r-red-500">
            <p className="text-xs font-bold text-text-muted mb-2">إجمالي الخسائر المالية</p>
            <div className="flex items-end gap-2">
               <h3 className="text-3xl font-black text-white">{stats.totalLoss.toFixed(2)}</h3>
               <span className="text-sm font-bold text-text-muted mb-1 underline decoration-red-500">د.أ</span>
            </div>
            <p className="text-[10px] text-text-muted mt-2">(مجموع الطلبات بدون رسوم التوصيل)</p>
         </div>
         <div className="bg-card/40 backdrop-blur-md rounded-2xl border border-white/5 p-6 border-r-4 border-r-amber-500">
            <p className="text-xs font-bold text-text-muted mb-2">إلغاء من قبل الزبائن</p>
            <div className="flex items-end gap-2">
               <h3 className="text-3xl font-black text-white">{stats.customerCount}</h3>
               <span className="text-sm font-bold text-text-muted mb-1">طلب</span>
            </div>
            <p className="text-[10px] text-text-muted mt-2">طلبات تم إنهاؤها بقرار من العميل</p>
         </div>
         <div className="bg-card/40 backdrop-blur-md rounded-2xl border border-white/5 p-6 border-r-4 border-r-blue-500">
            <p className="text-xs font-bold text-text-muted mb-2">إلغاء من قبل الإدارة</p>
            <div className="flex items-end gap-2">
               <h3 className="text-3xl font-black text-white">{stats.adminCount}</h3>
               <span className="text-sm font-bold text-text-muted mb-1">طلب</span>
            </div>
            <p className="text-[10px] text-text-muted mt-2">إلغاءات إدارية لأسباب تشغيلية</p>
         </div>
      </div>

      <div className="bg-card/40 backdrop-blur-md rounded-2xl border border-white/5 overflow-hidden">
        {loading ? (
          <div className="p-20 flex flex-col items-center gap-4">
            <div className="w-10 h-10 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
            <p className="text-text-muted animate-pulse">جاري تحميل السجلات...</p>
          </div>
        ) : cancellations.length === 0 ? (
          <div className="p-20 flex flex-col items-center text-center opacity-40">
            <XCircle className="w-16 h-16 mb-4" />
            <h3 className="text-xl font-bold text-white mb-2">لا يوجد طلبات ملغاة</h3>
            <p className="text-sm">سجل الإلغاءات فارغ حالياً.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="bg-white/5 border-b border-white/5">
                  <th className="p-4 text-xs font-bold text-text-muted uppercase tracking-wider"><Hash className="w-3 h-3 inline ml-1" /> رقم الطلب</th>
                  <th className="p-4 text-xs font-bold text-text-muted uppercase tracking-wider"><User className="w-3 h-3 inline ml-1" /> العميل</th>
                  <th className="p-4 text-xs font-bold text-text-muted uppercase tracking-wider"><AlertTriangle className="w-3 h-3 inline ml-1" /> سبب الإلغاء</th>
                  <th className="p-4 text-xs font-bold text-text-muted uppercase tracking-wider"><ShieldCheck className="w-3 h-3 inline ml-1" /> القائم بالإلغاء</th>
                  <th className="p-4 text-xs font-bold text-text-muted uppercase tracking-wider"><Clock className="w-3 h-3 inline ml-1" /> الحالة وقتها</th>
                  <th className="p-4 text-xs font-bold text-text-muted uppercase tracking-wider"><Calendar className="w-3 h-3 inline ml-1" /> التاريخ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {cancellations.map((order) => {
                  const cancelData = order.cancellation || {};
                  return (
                    <tr key={order.id} className="hover:bg-white/5 transition-colors group">
                      <td className="p-4">
                        <span className="font-mono text-xs font-bold text-primary group-hover:text-primary-light">
                          #{order.orderNumber?.split('-').pop() || order.orderId}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex flex-col">
                          <span className="text-sm font-bold text-white">{order.customerName}</span>
                          <span className="text-[10px] text-text-muted">{order.customerPhone}</span>
                        </div>
                      </td>
                      <td className="p-4 max-w-[250px]">
                        <p className="text-xs text-danger font-medium line-clamp-2">{cancelData.reason || 'غير محدد'}</p>
                      </td>
                      <td className="p-4 text-center">
                        <span className={cn(
                          "px-2 py-1 rounded text-[10px] font-black uppercase",
                          cancelData.cancelledBy === 'customer' ? 'bg-amber-500/10 text-amber-500' : 'bg-blue-500/10 text-blue-500'
                        )}>
                          {cancelData.cancelledBy === 'customer' ? 'العميل' : (cancelData.adminName || 'المدير العام')}
                        </span>
                      </td>
                      <td className="p-4">
                        {getStatusBadge(cancelData.previousStatus || 'unknown')}
                      </td>
                      <td className="p-4 whitespace-nowrap">
                        <div className="flex flex-col text-left">
                          <span className="text-[11px] font-bold text-white">
                            {format(new Date(cancelData.createdAt || order.updatedAt), 'dd MMMM yyyy', { locale: ar })}
                          </span>
                          <span className="text-[10px] text-text-muted">
                            {format(new Date(cancelData.createdAt || order.updatedAt), 'hh:mm a', { locale: ar })}
                          </span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default CancelledOrders;
