const express = require('express');
const authenticateToken = require('../middleware/auth');
const upload = require('../middleware/upload');
const { getAllCategories, createCategory, updateCategory, deleteCategory } = require('../controllers/categoryController');

const router = express.Router();

router.get('/', getAllCategories);
router.post('/', authenticateToken, upload.single('image'), createCategory);
router.put('/:id', authenticateToken, upload.single('image'), updateCategory);
router.delete('/:id', authenticateToken, deleteCategory);

module.exports = router;
