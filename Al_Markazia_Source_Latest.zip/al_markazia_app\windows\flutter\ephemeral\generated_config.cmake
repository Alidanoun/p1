# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\User\\Desktop\\f\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "c:\\Users\\User\\Desktop\\p4\\al_markazia_app" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.1+2" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 1 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 2 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\User\\Desktop\\f\\flutter"
  "PROJECT_DIR=c:\\Users\\User\\Desktop\\p4\\al_markazia_app"
  "FLUTTER_ROOT=C:\\Users\\User\\Desktop\\f\\flutter"
  "FLUTTER_EPHEMERAL_DIR=c:\\Users\\User\\Desktop\\p4\\al_markazia_app\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=c:\\Users\\User\\Desktop\\p4\\al_markazia_app"
  "FLUTTER_TARGET=c:\\Users\\User\\Desktop\\p4\\al_markazia_app\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDEuMg==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049OTA2NzNhNGVlZg==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049NmMwYmFhZWJmNw==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMS4w"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=c:\\Users\\User\\Desktop\\p4\\al_markazia_app\\.dart_tool\\package_config.json"
)
