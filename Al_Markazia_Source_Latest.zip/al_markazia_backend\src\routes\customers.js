const express = require('express');
const router = express.Router();
const customerController = require('../controllers/customerController');

// Endpoint to update device FCM token
router.post('/fcm-token', customerController.updateFcmToken);

// Authentication endpoints
router.post('/login', customerController.loginCustomer);
router.post('/register', customerController.registerCustomer);

module.exports = router;
