const jwt = require('jsonwebtoken');
const logger = require('../utils/logger');

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    logger.security('Access denied: No token provided', { 
      ip: req.ip, 
      endpoint: req.originalUrl 
    });
    return res.status(401).json({ error: 'Access denied' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      const reason = err.name === 'TokenExpiredError' ? 'expired token' : 'invalid token';
      logger.security(`Failed JWT validation: ${reason}`, { 
        ip: req.ip, 
        endpoint: req.originalUrl,
        reason: err.message
      });
      return res.status(403).json({ error: 'Invalid token' });
    }
    
    // Strict requirement: Only 'admin' role allowed
    if (user.role !== 'admin') {
      logger.security('Unauthorized access attempt: Not an admin', { 
        ip: req.ip, 
        endpoint: req.originalUrl,
        userId: user.id 
      });
      return res.status(403).json({ error: 'Unauthorized: Admin access only' });
    }

    req.user = user;
    next();
  });
};

module.exports = authenticateToken;
