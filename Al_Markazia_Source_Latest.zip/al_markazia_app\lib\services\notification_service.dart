import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_messaging/firebase_messaging.dart';
import 'api_service.dart';
import '../main.dart';
import '../screens/notifications_screen.dart';
import '../screens/notification_detail_screen.dart';

class NotificationService extends ChangeNotifier {
  static final NotificationService _instance = NotificationService._internal();
  factory NotificationService() => _instance;
  NotificationService._internal();

  IO.Socket? socket;
  final FirebaseMessaging _fcm = FirebaseMessaging.instance;
  List<dynamic> notifications = [];
  int unreadCount = 0;
  String? currentPhone;
  bool _isInitialized = false;
  bool _isFCMListenersRegistered = false;
  final List<String> _recentIds = [];

  final FlutterLocalNotificationsPlugin _localNotifications = FlutterLocalNotificationsPlugin();

  Future<void> init([String? phone]) async {
    currentPhone = phone;

    if (!_isInitialized) {
      // 1. Setup Local Notifications (ONLY ONCE)
      const AndroidInitializationSettings initSettingsAndroid = AndroidInitializationSettings('@mipmap/ic_launcher');
      const DarwinInitializationSettings initSettingsIOS = DarwinInitializationSettings(
        requestSoundPermission: true,
        requestBadgePermission: true,
        requestAlertPermission: true,
      );
      const InitializationSettings initSettings = InitializationSettings(
        android: initSettingsAndroid,
        iOS: initSettingsIOS,
      );
      await _localNotifications.initialize(
        initSettings,
        onDidReceiveNotificationResponse: _onSelectNotification,
      );

      // --- NEW: Handle Cold Start for Local Notifications ---
      final NotificationAppLaunchDetails? launchDetails = await _localNotifications.getNotificationAppLaunchDetails();
      if (launchDetails != null && launchDetails.didNotificationLaunchApp) {
        if (launchDetails.notificationResponse?.payload != null) {
          try {
            final data = json.decode(launchDetails.notificationResponse!.payload!);
            _safeNavigate(data);
          } catch (e) {
            print('Error decoding launch payload: $e');
          }
        }
      }

      // --- NEW: Handle Cold Start for FCM ---
      RemoteMessage? initialMessage = await _fcm.getInitialMessage();
      if (initialMessage != null) {
        print('App launched via FCM initial message');
        _safeNavigate({
          'id': initialMessage.data['id'],
          'title': initialMessage.notification?.title,
          'message': initialMessage.notification?.body,
          'type': initialMessage.data['type'],
          'createdAt': DateTime.now().toIso8601String(),
        });
      }

      // 2. Setup Socket (ONLY ONCE)
      socket = IO.io(ApiService.baseUrl, <String, dynamic>{
        'transports': ['websocket'],
        'autoConnect': true,
      });

      socket?.onConnect((_) {
        print('Socket Connected (ID: ${socket?.id})');
        if (currentPhone != null) {
          socket?.emit('join_customer', currentPhone);
        }
      });

      socket?.on('customer_notification', _handleNewNotification);
      socket?.on('new_broadcast', _handleNewNotification);
      
      _isInitialized = true;
    }

    // Repeated Logic (Update identity on every init call)
    if (socket != null && socket!.connected && currentPhone != null) {
      socket?.emit('join_customer', currentPhone);
    }
    
    await fetchNotifications();
    await _setupFCM(phone);
  }

  Future<void> _setupFCM(String? phone) async {
    // 1. Request Permission
    NotificationSettings settings = await _fcm.requestPermission(
      alert: true,
      badge: true,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      // 2. Get Token & Sync (Always sync if phone is provided)
      String? token = await _fcm.getToken();
      if (token != null) {
        if (phone != null) {
          await _updateTokenOnBackend(phone, token);
        }
      }

      // 3. One-time Setup: Topic Subscription and Listeners
      if (!_isFCMListenersRegistered) {
        await _fcm.subscribeToTopic('all_users');

        // 4. Handle Foreground Messages
        FirebaseMessaging.onMessage.listen((RemoteMessage message) {
          print('Got a message whilst in the foreground!');
          if (message.notification != null) {
            _handleNewNotification({
              'id': message.data['id'],
              'title': message.notification!.title,
              'message': message.notification!.body,
              'type': message.data['type'],
              'createdAt': DateTime.now().toIso8601String(),
            });
          }
        });
        
        // 5. Handle notification tap when app is in background but not terminated
        FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
          print('Notification caused app to open from background state');
           _safeNavigate({
              'id': message.data['id'],
              'title': message.notification?.title,
              'message': message.notification?.body,
              'type': message.data['type'],
              'createdAt': DateTime.now().toIso8601String(),
            });
        });

        _isFCMListenersRegistered = true;
      }
    }
  }

  Future<void> _updateTokenOnBackend(String? phone, String token) async {
    if (phone == null) return;
    try {
      final response = await http.post(
        Uri.parse('${ApiService.baseUrl}/customers/fcm-token'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'phone': phone, 'fcmToken': token}),
      );
      if (response.statusCode == 200) {
        print('✅ FCM Token synced with backend for $phone');
      }
    } catch (e) {
      print('❌ Failed to sync FCM token: $e');
    }
  }

  void _handleNewNotification(dynamic data) {
    // 🛡️ De-duplication Logic: Prevent double notifications (FCM + Socket.io)
    final String? notificationId = data['id']?.toString();
    
    if (notificationId != null) {
      if (_recentIds.contains(notificationId)) {
        print('♻️ Duplicate notification blocked (ID: $notificationId)');
        return;
      }
      _recentIds.add(notificationId);
      print('🔔 Handled Notification ID: $notificationId');
      
      // Keep de-duplication ID for a longer period (60s) to bridge network delays
      Future.delayed(const Duration(seconds: 60), () {
        _recentIds.remove(notificationId);
      });
    }

    print('Processing New Notification: $data');
    
    // Check if notification already exists in the list to avoid duplicate UI entries
    final bool alreadyInList = notifications.any((n) => n['id']?.toString() == notificationId);
    if (!alreadyInList) {
      notifications.insert(0, data);
      unreadCount++;
      notifyListeners();
    }

    // 🚀 DUPLICATE PREVENTION LOGIC:
    // Only show the "Manual" Local Notification if the app is in the FOREGROUND.
    // If the app is in the Background/Terminated, the OS already shows the "System" FCM notification.
    final bool isForeground = WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed;
    
    if (isForeground) {
      print('📱 App is in Foreground: Showing manual local notification banner');
      _showLocalNotification(data);
    } else {
      print('💤 App is in Background: Skipping manual notification (OS handles it)');
    }
  }

  void _onSelectNotification(NotificationResponse response) {
    if (response.payload != null) {
      try {
        final data = json.decode(response.payload!);
        _safeNavigate(data);
      } catch (e) {
        print('Error parsing notification payload: $e');
      }
    }
  }

  Future<void> _safeNavigate(dynamic data) async {
    print('🔔 Attempting to navigate to notification detail: ${data['id']}');
    
    // Retry Loop: wait for navigatorKey.currentState to be available
    // Especially important for cold starts or background-to-foreground transitions
    int attempts = 0;
    while (navigatorKey.currentState == null && attempts < 15) {
      print('⏳ Navigator not ready yet, attempt ${attempts + 1}/15. Waiting...');
      await Future.delayed(const Duration(milliseconds: 500));
      attempts++;
    }

    if (navigatorKey.currentState != null) {
      print('✅ Navigator is READY. Pushing detail screen.');
      
      // Mark as read if it has an ID
      if (data['id'] != null) markAsRead(data['id']);

      navigatorKey.currentState!.push(
        MaterialPageRoute(
          builder: (context) => NotificationDetailScreen(notification: data),
        ),
      );
    } else {
      print('❌ CRITICAL: Navigator failed to become ready after several attempts.');
    }
  }

  Future<void> _showLocalNotification(dynamic data) async {
    const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
      'almarkazia_channel',
      'Al Markazia Notifications',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
    );
    const NotificationDetails platformDetails = NotificationDetails(
      android: androidDetails, 
      iOS: DarwinNotificationDetails(presentSound: true, presentAlert: true, presentBadge: true)
    );
    
    await _localNotifications.show(
      DateTime.now().millisecond,
      data['title'] ?? 'New Notification',
      data['message'] ?? '',
      platformDetails,
      payload: json.encode(data),
    );
  }

  Future<void> fetchNotifications() async {
    if (currentPhone == null) return;
    try {
      final response = await http.get(Uri.parse('${ApiService.baseUrl}/notifications?phone=$currentPhone'));
      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        notifications = data;
        unreadCount = data.where((n) => n['isRead'] == false).length;
        notifyListeners();
      }
    } catch (e) {
      print('Failed to fetch notifications: $e');
    }
  }

  Future<void> markAsRead(int id) async {
    try {
      await http.put(Uri.parse('${ApiService.baseUrl}/notifications/$id/read'));
      final index = notifications.indexWhere((n) => n['id'] == id);
      if (index != -1 && !notifications[index]['isRead']) {
        notifications[index]['isRead'] = true;
        unreadCount = (unreadCount > 0) ? unreadCount - 1 : 0;
        notifyListeners();
      }
    } catch (e) {
      print('Failed to mark read: $e');
    }
  }

  void disposeSocket() {
    socket?.disconnect();
    socket?.dispose();
  }
}
