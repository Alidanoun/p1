const express = require('express');
const { 
  submitReview, 
  getItemReviews, 
  getAllReviews, 
  toggleApproval, 
  deleteReview 
} = require('../controllers/reviewController');
const authenticateToken = require('../middleware/auth');

const router = express.Router();

// Public routes for mobile App
router.post('/', submitReview);
router.get('/item/:itemId', getItemReviews);

// Protected routes for Admin Panel
router.get('/', authenticateToken, getAllReviews);
router.put('/:id/approve', authenticateToken, toggleApproval);
router.delete('/:id', authenticateToken, deleteReview);

module.exports = router;
