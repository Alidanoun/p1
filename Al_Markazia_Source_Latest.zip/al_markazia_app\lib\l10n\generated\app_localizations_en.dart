// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appName => 'Al Markazia Restaurant';

  @override
  String get welcome => 'Welcome';

  @override
  String get selectLanguage => 'Select Language';

  @override
  String get arabic => 'العربية';

  @override
  String get english => 'English';

  @override
  String get continueBtn => 'Continue';

  @override
  String get myOrders => 'My Orders';

  @override
  String get activeOrders => 'Active Orders';

  @override
  String get orderHistory => 'Order History';

  @override
  String get favorites => 'Favorites';

  @override
  String get settings => 'Settings';

  @override
  String get darkMode => 'Dark Mode';

  @override
  String get language => 'Language';

  @override
  String get logout => 'Logout';

  @override
  String get home => 'Home';

  @override
  String get cart => 'Cart';

  @override
  String get pending => 'Pending';

  @override
  String get preparing => 'Preparing';

  @override
  String get ready => 'Ready';

  @override
  String get delivered => 'Delivered';

  @override
  String get noActiveOrders => 'No active orders yet';

  @override
  String get noHistoryOrders => 'Order history is empty';

  @override
  String get invoiceDetails => 'Invoice Details';

  @override
  String get orderIdLabel => 'Order #';

  @override
  String get totalAmount => 'Total Amount';

  @override
  String get reorder => 'Reorder';

  @override
  String get rateOrder => 'Rate Order';

  @override
  String get cancel => 'Cancel';

  @override
  String get confirm => 'Confirm';

  @override
  String get close => 'Close';

  @override
  String get addToCart => 'Add to Cart';

  @override
  String get addedToCart => 'Added to cart successfully ✅';

  @override
  String selectRequired(Object name) {
    return 'Please select $name first ⚠️';
  }

  @override
  String get required => 'Required';

  @override
  String get optional => 'Optional';

  @override
  String get notes => 'Extra Notes';

  @override
  String get notesHint => 'No onions, extra toasted...';

  @override
  String get customerReviews => 'Customer Reviews';

  @override
  String get noReviews => 'No reviews yet. Be the first to rate this dish!';

  @override
  String get addReview => 'Add Review';

  @override
  String get reviewDialogTitle => 'What do you think of this dish?';

  @override
  String get reviewHint => 'Share your experience (optional)';

  @override
  String get submitReview => 'Submit Review';

  @override
  String get reviewSuccess =>
      'Thank you for your rating! It will be reviewed soon ✅';

  @override
  String get cartTitle => 'Shopping Cart';

  @override
  String get emptyCart => 'Your cart is empty';

  @override
  String get addPlates => 'Add delicious dishes';

  @override
  String get clearCart => 'Clear Cart';

  @override
  String get clearCartConfirm => 'Are you sure you want to empty your cart?';

  @override
  String get items => 'items';

  @override
  String get totalPriceLabel => 'Grand Total';

  @override
  String get confirmOrder => 'Confirm Order';

  @override
  String get currency => 'JD';

  @override
  String get reorderConfirm =>
      'Do you want to add all items from this order to your current cart?';

  @override
  String get ratingHint => 'Add your comments here...';

  @override
  String get brandSubtitle => 'Chef Food';

  @override
  String get delivery => 'Delivery';

  @override
  String get takeaway => 'Takeaway';

  @override
  String get orderTypeLabel => 'Order Type:';

  @override
  String get nameLabel => 'Name (Required)';

  @override
  String get phoneLabel => 'Phone (Required)';

  @override
  String get nameRequired => 'Name is required';

  @override
  String get phoneRequired => 'Phone is required';

  @override
  String get deliveryAddress => 'Delivery Address 📍';

  @override
  String get zoneLabel => 'Zone *';

  @override
  String get streetLabel => 'Street *';

  @override
  String get buildingLabel => 'Building / House No.';

  @override
  String get selectZoneHint => 'Select delivery zone...';

  @override
  String get searchZoneHint => 'Search for your zone...';

  @override
  String get noZonesFound => 'No zones match your search';

  @override
  String get pickupTimeLabel => 'Pickup time:';

  @override
  String get asap => 'Pick up as soon as ready';

  @override
  String get atTime => 'At a specific time';

  @override
  String get selectTime => 'Select Time';

  @override
  String get orderSummary => 'Order Summary:';

  @override
  String get subtotal => 'Subtotal:';

  @override
  String get deliveryFee => 'Delivery Fee:';

  @override
  String get finalTotal => 'Grand Total:';

  @override
  String get confirmOrderNow => 'Confirm Order Now';

  @override
  String get orderConfirmedMsg => 'Order confirmed successfully! 🎉';

  @override
  String get selectZoneError => 'Please select a delivery zone';

  @override
  String get logoutConfirm => 'Are you sure you want to logout?';

  @override
  String get whatsAppError =>
      'Could not open WhatsApp. Make sure it\'s installed.';

  @override
  String get phoneError => 'Could not open phone app.';

  @override
  String get supportError => 'Error contacting support.';

  @override
  String get loyaltyPoints => 'Loyalty Points';

  @override
  String get points => 'Points';

  @override
  String get notifications => 'Notifications';

  @override
  String get guest => 'Guest';

  @override
  String get phoneNotAvailable => 'Phone not available';

  @override
  String get loginTitle => 'Login';

  @override
  String get loginTab => 'Login';

  @override
  String get registerTab => 'Register';

  @override
  String get fullNameLabel => 'Full Name';

  @override
  String get loginSuccessMsg => 'Logged in successfully';

  @override
  String get registerSuccessMsg => 'Account created successfully';

  @override
  String get fieldsReviewMsg => 'Please review required fields';

  @override
  String get allFieldsRequiredMsg => 'Please complete all required data';

  @override
  String get registerAction => 'Register Account';

  @override
  String get startingFrom => 'starting from';

  @override
  String get newTag => 'New';

  @override
  String get categoryAll => 'All';

  @override
  String get welcomeTitle => 'Welcome';

  @override
  String get welcomeDesc =>
      'At Al-Markazia Restaurant, we offer you the most delicious food and the best services for an unforgettable dining experience.';

  @override
  String get backToHome => 'Back to Home';

  @override
  String get asSelected => 'As selected';

  @override
  String get bestseller => '🔥 Bestseller';

  @override
  String get noDishesFound => 'No dishes found';

  @override
  String get retry => 'Retry';

  @override
  String get notificationsTitle => 'Notifications';

  @override
  String get noNotifications => 'No notifications yet';

  @override
  String get notificationDetails => 'Notification Details';

  @override
  String notificationExpiry(Object days) {
    return 'This notification will expire in $days days';
  }

  @override
  String get messageContent => 'Message Content:';

  @override
  String get whatsapp => 'WhatsApp';

  @override
  String get support => 'Support';

  @override
  String get unknownCustomer => 'Unknown Customer';

  @override
  String get connectionError =>
      'Could not connect to server. Make sure the service is running.';

  @override
  String get orderSendError => 'Failed to send order';

  @override
  String get loginFailed => 'Login failed';

  @override
  String get registerFailed => 'Registration failed';

  @override
  String get reviewFailed => 'Failed to submit review';

  @override
  String get prepTime => '20 - 30 min';

  @override
  String get inRoute => 'In Route';

  @override
  String get waitingCancellation => 'Waiting Cancellation';

  @override
  String get cancelOrder => 'Cancel Order';

  @override
  String get cancelReasonTitle => 'Why do you want to cancel?';

  @override
  String get cancelReason1 => 'I chose the wrong item';

  @override
  String get cancelReason2 => 'Restaurant delay in preparation';

  @override
  String get cancelReason3 => 'Selected items are not available';

  @override
  String get cancelReason4 => 'Other reasons';

  @override
  String get otherReasonNote =>
      'Your cancellation request is under review. Customer service will contact you within 3-5 minutes, or you can call them directly.';

  @override
  String get callSupport => 'Call Support';
}
