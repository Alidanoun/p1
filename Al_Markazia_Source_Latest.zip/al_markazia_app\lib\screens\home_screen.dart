import 'dart:async';
import 'package:flutter/material.dart';
import '../models/menu_item.dart';
import '../services/api_service.dart';
import '../services/storage_service.dart';
import 'item_details.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../services/notification_service.dart';
import 'notifications_screen.dart';
import '../l10n/generated/app_localizations.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ApiService _apiService = ApiService();
  List<Category> _categories = [];
  List<MenuItem> _menuItems = [];
  
  String _activeCategory = ''; // Initialized in build
  bool _isLoading = true;
  String? _errorMessage;

  String _searchQuery = '';
  bool _isSearching = false;
  
  // Featured Slider Logic
  final PageController _featuredPageController = PageController();
  int _currentFeaturedIndex = 0;
  Timer? _featuredTimer;
  List<int> _favorites = [];

  @override
  void initState() {
    super.initState();
    _fetchData();
    NotificationService().addListener(_onNotifUpdate);
    StorageService.instance.addListener(_onStorageChange);
    // Initialize favorites
    _favorites = StorageService.instance.getFavorites();
  }

  void _startFeaturedTimer() {
    _featuredTimer?.cancel();
    _featuredTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (_menuItems.isEmpty) return;
      final featuredCount = _menuItems.where((i) => i.isFeatured).take(5).length;
      if (featuredCount <= 1) return;

      if (mounted && _featuredPageController.hasClients) {
        _currentFeaturedIndex = (_currentFeaturedIndex + 1) % featuredCount;
        _featuredPageController.animateToPage(
          _currentFeaturedIndex,
          duration: const Duration(milliseconds: 800),
          curve: Curves.fastOutSlowIn,
        );
      }
    });
  }

  void _onNotifUpdate() {
    if (mounted) setState(() {});
  }
  
  void _onStorageChange() {
    if (mounted) {
      setState(() {
        _favorites = StorageService.instance.getFavorites();
      });
    }
  }

  @override
  void dispose() {
    _featuredTimer?.cancel();
    _featuredPageController.dispose();
    NotificationService().removeListener(_onNotifUpdate);
    StorageService.instance.removeListener(_onStorageChange);
    super.dispose();
  }

  Future<void> _fetchData({bool silent = false}) async {
    try {
      if (!silent) {
        setState(() {
          _isLoading = true;
          _errorMessage = null;
        });
      }
      final cats = await _apiService.fetchCategories();
      final items = await _apiService.fetchMenuItems();
      
      setState(() {
        _categories = cats;
        _menuItems = items;
        _isLoading = false;
      });
      _startFeaturedTimer();
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = e.toString();
        });
      }
    }
  }

  List<MenuItem> get _filteredItems {
    List<MenuItem> list = _menuItems;
    final allLabel = AppLocalizations.of(context)!.categoryAll;
    if (_activeCategory.isNotEmpty && _activeCategory != allLabel) {
      list = list.where((i) => i.category == _activeCategory || i.displayCategory == _activeCategory || (i.categoryEn == _activeCategory)).toList();
    }
    if (_searchQuery.isNotEmpty) {
      list = list.where((i) => i.displayTitle.toLowerCase().contains(_searchQuery.toLowerCase())).toList();
    }
    return list;
  }

  @override
  Widget build(BuildContext context) {
    // Force dark visual elements even if the app theme is weird (to match design)
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = Theme.of(context).scaffoldBackgroundColor;
    final primaryColor = Theme.of(context).primaryColor;

    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        bottom: false,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top Section (Search Bar & Notifications) - Moved to sticky header later or keep minimal
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 20, top: 12, bottom: 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${AppLocalizations.of(context)!.welcome}،',
                        style: TextStyle(color: isDark ? Colors.white70 : Colors.black54, fontSize: 12),
                      ),
                      Text(
                        StorageService.instance.getCurrentUser()?['name'] ?? AppLocalizations.of(context)!.guest,
                        style: TextStyle(color: isDark ? Colors.white : Colors.black, fontSize: 18, fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                           // Expand search later
                        },
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: isDark ? Colors.white12 : Colors.black12),
                          ),
                          child: Icon(Icons.search_rounded, color: isDark ? Colors.white : Colors.black),
                        ),
                      ),
                      const SizedBox(width: 8),
                      // Notification Bell
                      GestureDetector(
                        onTap: () {
                          Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsScreen()));
                        },
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: isDark ? Colors.white12 : Colors.black12),
                          ),
                          child: Stack(
                            alignment: Alignment.center,
                            children: [
                              Icon(
                                NotificationService().unreadCount > 0 
                                    ? Icons.notifications_active_rounded 
                                    : Icons.notifications_none_rounded, 
                                color: isDark ? Colors.white : Colors.black87, 
                              ).animate(
                                key: ValueKey(NotificationService().unreadCount),
                                target: NotificationService().unreadCount > 0 ? 1 : 0
                              ).shake(duration: 600.ms, hz: 4),
                              
                              if (NotificationService().unreadCount > 0)
                                Positioned(
                                  top: 0,
                                  right: 0,
                                  child: Container(
                                    padding: const EdgeInsets.all(3),
                                    decoration: const BoxDecoration(color: Colors.redAccent, shape: BoxShape.circle),
                                    child: const SizedBox(width: 6, height: 6),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
            
            // Grid Body Content (Scrollable part)
            Expanded(
              child: _isLoading 
                ? Center(child: CircularProgressIndicator(color: primaryColor))
                : RefreshIndicator(
                    onRefresh: () => _fetchData(silent: true),
                    color: primaryColor,
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
                      child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // 1. Featured Auto-Slider
                        _buildFeaturedSlider(primaryColor, isDark),
                        
                        const SizedBox(height: 24),
                        
                        // 2. Categories Row
                        SizedBox(
                          height: 48,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            physics: const BouncingScrollPhysics(),
                            children: [
                              _buildCategoryTab(AppLocalizations.of(context)!.categoryAll, primaryColor, isAll: true),
                              ..._categories.map((c) => _buildCategoryTab(c.displayName, primaryColor)).toList(),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        
                        // 3. Grid View
                        const SizedBox(height: 12),
                        _buildBody(primaryColor),
                      ],
                    ),
                  ),
                ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeaturedSlider(Color primaryColor, bool isDark) {
    if (_menuItems.isEmpty) return const SizedBox.shrink();
    
    // Get up to 5 featured items
    final featuredItems = _menuItems.where((i) => i.isFeatured).take(5).toList();
    if (featuredItems.isEmpty) return const SizedBox.shrink();

    return Column(
      children: [
        SizedBox(
          height: 220,
          child: PageView.builder(
            controller: _featuredPageController,
            onPageChanged: (index) {
              setState(() {
                _currentFeaturedIndex = index;
              });
            },
            itemCount: featuredItems.length,
            itemBuilder: (context, index) {
              final item = featuredItems[index];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  color: isDark ? const Color(0xFF1E1E1E) : Colors.grey.shade200,
                ),
                clipBehavior: Clip.antiAlias,
                child: InkWell(
                  onTap: () {
                    setState(() => _activeCategory = item.category);
                    _openItemDetails(item);
                  },
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (item.image.isNotEmpty)
                        item.image.startsWith('http')
                          ? CachedNetworkImage(
                              imageUrl: item.image,
                              fit: BoxFit.cover,
                            )
                          : Image.asset('assets/${item.image}', fit: BoxFit.cover),
                      
                      DecoratedBox(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [
                              Colors.black.withOpacity(0.8),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),
                      
                      Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: primaryColor.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: primaryColor.withOpacity(0.5)),
                              ),
                              child: Text(
                                AppLocalizations.of(context)!.bestseller,
                                style: TextStyle(color: primaryColor, fontSize: 10, fontWeight: FontWeight.bold),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              item.displayTitle,
                              style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              item.displayDescription,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white70, fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                      
                      Positioned(
                        bottom: 20,
                        left: 20,
                        child: Text(
                          '${item.displayPrice} ${AppLocalizations.of(context)!.currency}',
                          style: TextStyle(color: primaryColor, fontSize: 20, fontWeight: FontWeight.bold),
                        ),
                      )
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        // Dots indicator
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(featuredItems.length, (index) {
            final isActive = _currentFeaturedIndex == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              height: 6,
              width: isActive ? 20 : 6,
              decoration: BoxDecoration(
                color: isActive ? primaryColor : (isDark ? Colors.white24 : Colors.black26),
                borderRadius: BorderRadius.circular(3),
              ),
            );
          }),
        )
      ],
    );
  }

  Widget _buildBody(Color primaryColor) {
    if (_isLoading) {
      return Center(child: CircularProgressIndicator(color: primaryColor));
    }
    if (_errorMessage != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.wifi_off_rounded, size: 64, color: primaryColor.withOpacity(0.5)),
              const SizedBox(height: 16),
              Text(_errorMessage!, textAlign: TextAlign.center, style: const TextStyle(height: 1.5)),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _fetchData,
                child: Text(AppLocalizations.of(context)!.retry),
              )
            ],
          ),
        ),
      );
    }

    if (_filteredItems.isEmpty) {
      return Center(child: Text(AppLocalizations.of(context)!.noDishesFound, style: const TextStyle(fontSize: 16)));
    }

    return GridView.builder(
      padding: const EdgeInsets.only(left: 20, right: 20, top: 0, bottom: 100), // padding bottom for bottom nav
      shrinkWrap: true, // Needed because it's inside a SingleChildScrollView now
      physics: const NeverScrollableScrollPhysics(), // Delegate scrolling to parent
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.75, // Taller cards
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
      ),
      itemCount: _filteredItems.length,
      itemBuilder: (context, index) {
        final item = _filteredItems[index];
        return _buildGridCard(item, primaryColor, index);
      },
    );
  }

  Widget _buildCategoryTab(String title, Color primaryColor, {bool isAll = false}) {
    final isActive = isAll 
        ? (_activeCategory.isEmpty || _activeCategory == AppLocalizations.of(context)!.categoryAll)
        : _activeCategory == title;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    final textColor = isActive 
        ? primaryColor 
        : (isDark ? Colors.white : Colors.black);
    
    return GestureDetector(
      onTap: () => setState(() => _activeCategory = isAll ? AppLocalizations.of(context)!.categoryAll : title),
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        alignment: Alignment.center,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: TextStyle(
                color: textColor,
                fontSize: 16,
                fontWeight: isActive ? FontWeight.w800 : FontWeight.w600,
              ),
            ),
            const SizedBox(height: 4),
            // Gold underline dot/line
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              height: 3,
              width: isActive ? 24 : 0,
              decoration: BoxDecoration(
                color: primaryColor,
                borderRadius: BorderRadius.circular(2),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildGridCard(MenuItem item, Color primaryColor, int index) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final cardBgColor = isDark ? const Color(0xFF1E1E1E) : Colors.white; // Soft dark gray for card
    
    // Simulate the premium card layout from the reference image
    return Container(
      decoration: BoxDecoration(
        color: cardBgColor,
        borderRadius: BorderRadius.circular(32),
        // Subtly lighter border or shadow for depth
        border: isDark ? Border.all(color: Colors.white.withOpacity(0.05)) : null,
        boxShadow: isDark ? null : [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 15,
            offset: const Offset(0, 5),
          )
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(32),
          onTap: () => _openItemDetails(item),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(32),
            child: Stack(
            fit: StackFit.expand,
            children: [
              // Background Image (Full bleed or large center)
              if (item.image.isNotEmpty)
                item.image.startsWith('http') 
                  ? CachedNetworkImage(
                      imageUrl: item.image,
                      fit: BoxFit.cover,
                      placeholder: (context, url) => Container(
                        color: isDark ? Colors.white.withOpacity(0.05) : Colors.black.withOpacity(0.05),
                        child: const Center(child: CircularProgressIndicator(strokeWidth: 2)),
                      ),
                      errorWidget: (context, url, error) => const Center(child: Icon(Icons.broken_image_rounded, size: 40, color: Colors.grey)),
                    )
                  : DecoratedBox(
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage('assets/${item.image}'),
                          fit: BoxFit.cover,
                          alignment: Alignment.center,
                        ),
                      ),
                    )
              else 
                Center(
                  child: Icon(Icons.restaurant, size: 48, color: isDark ? Colors.white24 : Colors.black12),
                ),
              
              // Gradient Overlay to ensure text legibility
              DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.black.withOpacity(0.7),
                      Colors.transparent,
                      Colors.black.withOpacity(0.6),
                    ],
                    stops: const [0.0, 0.4, 1.0],
                  ),
                ),
              ),
              
              // Content
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Top Section: Title & Favorite Button
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.displayTitle,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w900,
                                  height: 1.2,
                                  letterSpacing: 0.5,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              if (item.displayDescription.isNotEmpty) ...[
                                const SizedBox(height: 4),
                                Text(
                                  item.displayDescription,
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.7),
                                    fontSize: 11,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ]
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () => StorageService.instance.toggleFavorite(item.id),
                          child: Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: Colors.black.withOpacity(0.3),
                              shape: BoxShape.circle,
                            ),
                            child: Icon(
                              _favorites.contains(item.id) 
                                ? Icons.favorite_rounded 
                                : Icons.favorite_outline_rounded, 
                              color: _favorites.contains(item.id) ? Colors.redAccent : Colors.white,
                              size: 20,
                            ),
                          ),
                        ),
                      ],
                    ),
                    
                    // Bottom Section (Price & Button)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (item.startsFrom)
                              Text(AppLocalizations.of(context)!.startingFrom, style: const TextStyle(color: Colors.white60, fontSize: 10, fontWeight: FontWeight.bold)),
                            Text(
                              '${item.displayPrice.toStringAsFixed(item.displayPrice % 1 == 0 ? 0 : 2)} ${AppLocalizations.of(context)!.currency}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ],
                        ),
                        // Small Golden Button
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: primaryColor,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(
                            Icons.add, 
                            color: Colors.black,
                            size: 20,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      ).animate().fade(delay: (index * 40).ms, duration: 300.ms).slideY(begin: 0.1, end: 0, curve: Curves.easeOutCubic),
    );
  }

  void _openItemDetails(MenuItem item) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => ItemDetailsSheet(item: item),
    );
  }
}

