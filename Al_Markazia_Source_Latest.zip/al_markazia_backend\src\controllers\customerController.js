const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const logger = require('../utils/logger');

/**
 * Updates or creates a customer record and saves their FCM token.
 * This is called by the mobile app upon startup.
 */
const updateFcmToken = async (req, res) => {
  try {
    const { phone, fcmToken } = req.body;
    
    if (!phone || !fcmToken) {
      return res.status(400).json({ error: 'Phone and fcmToken are required' });
    }

    // Use upsert to handle both new and existing customers
    const customer = await prisma.customer.upsert({
      where: { phone },
      update: { fcmToken },
      create: { 
        phone, 
        fcmToken, 
        name: 'زبون جديد' // Default name if not exists
      }
    });

    logger.info('FCM Token updated for customer', { phone });
    res.json({ success: true, customer });
  } catch (error) {
    logger.error('Update FCM Token error', { error: error.message, phone: req.body?.phone });
    res.status(500).json({ error: 'فشل في تحديث بيانات الجهاز' });
  }
};

const loginCustomer = async (req, res) => {
  try {
    const { phone } = req.body;
    if (!phone) return res.status(400).json({ error: 'Phone is required' });
    
    // DB lookup — if no user found, return 401. Period.
    const customer = await prisma.customer.findUnique({ where: { phone } });
    if (!customer) {
      logger.security('Invalid customer login attempt: Phone not registered', { 
        identifier: phone, 
        ip: req.ip 
      });
      return res.status(401).json({ error: 'رقم الهاتف غير مسجل في النظام' });
    }
    
    logger.security('Valid customer login', { phone, ip: req.ip });
    res.json({ success: true, customer });
  } catch (error) {
    logger.error('Customer login error', { error: error.message, phone: req.body?.phone });
    res.status(500).json({ error: 'Failed to login' });
  }
};

const registerCustomer = async (req, res) => {
  try {
    const { name, phone } = req.body;
    if (!name || !phone) return res.status(400).json({ error: 'الاسم ورقم الهاتف مطلوبان' });
    
    const existing = await prisma.customer.findUnique({ where: { phone } });
    if (existing) {
      return res.status(400).json({ error: 'هذا الرقم مسجل مسبقاً يرجى تسجيل الدخول' });
    }
    
    const customer = await prisma.customer.create({ data: { name, phone } });
    logger.info('New customer registered', { phone, name });
    res.json({ success: true, customer });
  } catch (error) {
    logger.error('Customer registration error', { error: error.message, phone: req.body?.phone });
    res.status(500).json({ error: 'Failed to register' });
  }
};

module.exports = { updateFcmToken, loginCustomer, registerCustomer };
