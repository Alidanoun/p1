const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const itemRoutes = require('./routes/items');
const orderRoutes = require('./routes/orders');
const categoryRoutes = require('./routes/categories');
const notificationRoutes = require('./routes/notifications');
const customerRoutes = require('./routes/customers');
const reviewRoutes = require('./routes/reviews');
const settingsRoutes = require('./routes/settings');
const http = require('http');

const app = express();
const server = http.createServer(app);
const socketIo = require('./socket');
const PORT = process.env.PORT || 5000;

// Middleware
const allowedOrigins = (process.env.CORS_ORIGIN || '')
  .split(',')
  .map(o => o.trim())
  .filter(Boolean);

app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`CORS blocked: ${origin}`));
    }
  },
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
const logger = require('./utils/logger');

// Morgan Integration (HTTP Request Logging)
// Skip logging for health status
const skipFormats = (req, res) => {
  if (req.originalUrl === '/health') return true;
  if (process.env.NODE_ENV === 'production') {
    return res.statusCode < 400; // Only log 4xx and 5xx in prod
  }
  return false; // Log all in dev
};

// Custom format to include useful data
morgan.token('client-ip', (req) => req.ip || req.connection.remoteAddress);

app.use(morgan(
  ':client-ip - :method :url :status - :response-time ms',
  {
    stream: {
      write: (message) => logger.http(message.trim())
    },
    skip: skipFormats
  }
));

// Static folder for uploading images
app.use('/uploads', express.static('uploads'));

// API Routes
app.use('/auth', authRoutes);
app.use('/items', itemRoutes);
app.use('/orders', orderRoutes);
app.use('/categories', categoryRoutes);
app.use('/notifications', notificationRoutes);
app.use('/customers', customerRoutes);
app.use('/reviews', reviewRoutes);
app.use('/settings', settingsRoutes);

// Global Error Handler
app.use((err, req, res, next) => {
  logger.error(err.message, { 
    method: req.method, 
    endpoint: req.originalUrl, 
    stack: err.stack 
  });
  res.status(500).json({ error: 'حدث خطأ غير متوقع، يرجى المحاولة لاحقاً' });
});

// Process Level Interceptors
process.on('uncaughtException', (err) => {
  logger.error(`UNCAUGHT EXCEPTION: ${err.message}`, { stack: err.stack });
  // Graceful shutdown strategy
  setTimeout(() => process.exit(1), 1000);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error(`UNHANDLED REJECTION: ${reason}`, { reason });
  setTimeout(() => process.exit(1), 1000);
});

const io = socketIo.init(server);

io.on('connection', (socket) => {
  logger.info('Client connected', { socketId: socket.id });

  // Clients join based on dynamic room rules
  socket.on('join_customer', (customerId) => {
     if (customerId) {
       socket.join(`customer_${customerId}`);
       logger.info('Socket joined room', { socketId: socket.id, room: `customer_${customerId}` });
     }
  });

  socket.on('join_admin', () => {
     socket.join('admins');
     logger.info('Socket joined room', { socketId: socket.id, room: 'admins' });
  });

  socket.on('disconnect', () => {
    logger.info('Client disconnected', { socketId: socket.id });
  });
});

server.listen(PORT, '0.0.0.0', () => {
  const host = process.env.HOST_IP || 'localhost';
  logger.info(`🚀 Backend Server is running on http://${host}:${PORT}`);
  logger.info(`📡 Socket.io initialized and listening for events`);
});
