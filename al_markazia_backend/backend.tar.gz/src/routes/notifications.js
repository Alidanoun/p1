const express = require('express');
const router = express.Router();
const notificationController = require('../controllers/notificationController');
const { authenticateToken, isAdmin, isManager } = require('../middleware/auth');

// ✅ Customer: own notifications
router.get('/my-notifications', authenticateToken, notificationController.getMyNotifications);

// ✅ Admin: all admin notifications
router.get('/', authenticateToken, isManager, notificationController.getAdminNotifications);

// ✅ Test Push endpoint
router.post('/test-push', authenticateToken, isAdmin, notificationController.testPush);

// ✅ Mark single as read (ownership-checked)
router.put('/:id/read', authenticateToken, notificationController.markAsRead);

// ✅ Mark all as read (uses JWT identity only)
router.put('/read-all', authenticateToken, notificationController.markAllAsRead);

// ✅ Admin broadcast
router.post('/broadcast', authenticateToken, isAdmin, notificationController.broadcast);

module.exports = router;
