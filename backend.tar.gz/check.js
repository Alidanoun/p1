const express = require('express');

// Mock dependencies
const mockRedis = {
  get: async () => null,
  set: async () => null,
  setex: async () => null,
  del: async () => null,
  incr: async () => 1,
  expire: async () => null,
  on: () => {},
  duplicate: () => mockRedis
};
require.cache[require.resolve('./src/lib/redis.js')] = {
  id: require.resolve('./src/lib/redis.js'),
  filename: require.resolve('./src/lib/redis.js'),
  loaded: true,
  exports: mockRedis
};

const mockPrisma = {
  order: {
    findUnique: async () => null
  },
  idempotencyKey: {
    findUnique: async () => null,
    create: async () => null
  }
};
require.cache[require.resolve('./src/lib/prisma.js')] = {
  id: require.resolve('./src/lib/prisma.js'),
  filename: require.resolve('./src/lib/prisma.js'),
  loaded: true,
  exports: mockPrisma
};

const mockRouter = {
  post: (path, ...handlers) => {
    handlers.forEach((h, i) => {
      if (!h || typeof h !== 'function') {
        console.log(`POST ${path} index ${i} is undefined or not a function! Value:`, h);
      }
    });
  },
  get: (path, ...handlers) => {
    handlers.forEach((h, i) => {
      if (!h || typeof h !== 'function') {
        console.log(`GET ${path} index ${i} is undefined or not a function! Value:`, h);
      }
    });
  },
  patch: (path, ...handlers) => {
    handlers.forEach((h, i) => {
      if (!h || typeof h !== 'function') {
        console.log(`PATCH ${path} index ${i} is undefined or not a function! Value:`, h);
      }
    });
  },
  delete: (path, ...handlers) => {
    handlers.forEach((h, i) => {
      if (!h || typeof h !== 'function') {
        console.log(`DELETE ${path} index ${i} is undefined or not a function! Value:`, h);
      }
    });
  },
  use: () => {}
};

express.Router = () => mockRouter;

try {
  require('./src/routes/orders.js');
} catch (e) {
  console.error('Error requiring orders:', e);
}
